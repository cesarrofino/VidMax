# VidMax

Aplicação Android (Kotlin + HTML/CSS/JavaScript puro) para descarregar vídeos e músicas, navegar na Internet e organizar downloads.

## Como obter o APK (3 passos)
1. Crie um repositório no GitHub e envie **todo o conteúdo desta pasta** (incluindo a pasta oculta `.github`).
   - Se o envio pelo site não incluir `.github`: em *Add file → Create new file*, escreva o nome `.github/workflows/build.yml` e cole o conteúdo do ficheiro `build.yml` deste projeto.
2. Abra o separador **Actions → Build VidMax APK → Run workflow**.
3. Quando terminar (≈5–10 min), abra a execução e descarregue o artefacto **VidMax-debug-apk** (ZIP com `app-debug.apk`). Instale no telemóvel (permita "instalar apps desconhecidas").

### APK release assinado (opcional)
Crie estes *Secrets* no repositório: `VIDMAX_KEYSTORE_BASE64` (keystore em base64), `VIDMAX_KEYSTORE_PASSWORD`, `VIDMAX_KEY_ALIAS`, `VIDMAX_KEY_PASSWORD`. Execute o workflow com **build_release = true**.

## Estrutura
- `app/src/main/java/app/vidmax/` – Kotlin: `MainActivity` (ponte segura JS↔Kotlin), `Browser` (separadores), `Analyzer` (análise de links/HLS), `Downloads` + `DownloadService` (motor, pausa/retoma HTTP Range, notificações), `Storage`, `Store`, `PlayerActivity` + `PlaybackService` (Media3).
- `app/src/main/assets/ui/` – interface HTML/CSS/JS (Glassmorphism, tema claro/escuro).
- `.github/workflows/build.yml` – compilação automática.

## Funcionamento e limites
- Descarrega ficheiros que o servidor realmente disponibiliza: links diretos, `<video>/<audio>/<source>`, `og:video` e HLS (`.m3u8`) não encriptado (saída `.ts` ou `.mp4`). As qualidades listadas vêm do servidor/lista HLS – nunca são inventadas.
- YouTube, TikTok, Instagram, Facebook e X são **reconhecidos**, mas o VidMax não extrai nem contorna proteções: mostra uma mensagem e encaminha para as opções oficiais.
- Não suporta DRM, streams encriptados (AES/SAMPLE-AES), DASH, nem transmissões em direto. HLS com áudio em faixa separada é marcado "sem áudio incorporado".
- Modo privado: não guarda histórico nem cache, mas os cookies do WebView são partilhados com os separadores normais (limitação do Android).
- "Conteúdos populares" não foi incluído (não existe fonte legítima gratuita sem chave de API).
- Android mínimo: 7.0 (API 24).
