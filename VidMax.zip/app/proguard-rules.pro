-keepclassmembers class app.vidmax.UiBridge {
    @android.webkit.JavascriptInterface <methods>;
}
