(function () {
  const { S, $, $$, esc, icon, native } = VM;
  const activeTab = () => S.browser.tabs.find(t => t.id === S.browser.active) || null;
  const isBlank = () => { const t = activeTab(); return !t || !t.url; };
  VM.isBlankTab = isBlank;
  const disp = t => { if (!t || !t.url) return 'Pesquisar ou escrever endereço'; return VM.host(t.url) + (t.url.indexOf('https://') === 0 ? '' : ' (não seguro)'); };

  VM.renderBrowser = function () {
    return `<div class="page browser"><div class="bchrome">
<div class="brow"><button class="ib" id="bBack" data-act="bBack" aria-label="Voltar">${icon('back')}</button><button class="ib" id="bFwd" data-act="bFwd" aria-label="Avançar">${icon('fwd')}</button>
<button class="addr" id="bAddr" data-act="bAddr"><span></span></button>
<button class="ib" id="bReload" data-act="bReload" aria-label="Atualizar">${icon('refresh')}</button>
<button class="ib" id="bTabs" data-act="bTabs" aria-label="Separadores"><span class="tabcount">1</span></button>
<button class="ib" data-act="bMenu" aria-label="Menu">${icon('more')}</button></div>
<div class="pbar"><i id="bProg"></i></div></div>
<div id="hole"><div id="startHost"></div><button id="fab" data-act="bScan" aria-label="Descarregar multimédia">${icon('download')}<span class="fb" id="fabBadge" style="display:none"></span></button></div></div>`;
  };

  VM.patchBrowser = function () {
    if (S.route !== 'browser') return;
    const t = activeTab(), b = S.browser;
    const back = $('#bBack'); if (!back) return;
    back.disabled = !(b.canBack); $('#bFwd').disabled = !(b.canForward);
    const addr = $('#bAddr');
    if (!addr.querySelector('input')) addr.innerHTML = `${icon('lock')}<span>${esc(disp(t))}</span>`;
    if (t && t.url && t.url.indexOf('https://') !== 0) { const l = addr.querySelector('svg'); if (l) l.style.color = 'var(--danger)'; }
    $('#bReload').innerHTML = icon(t && t.loading ? 'x' : 'refresh');
    $('#bProg').style.width = (t && t.loading ? t.progress : 0) + '%';
    const tc = $('#bTabs'); tc.querySelector('.tabcount').textContent = b.tabs.length;
    tc.classList.toggle('privon', !!(t && t.priv));
    const fb = $('#fabBadge'); if (b.media > 0) { fb.style.display = 'flex'; fb.textContent = b.media > 9 ? '9+' : b.media; } else fb.style.display = 'none';
    const host = $('#startHost');
    const want = isBlank();
    if (want && !host.firstChild) { host.innerHTML = startPage(t); bindStart(); }
    else if (!want && host.firstChild) host.innerHTML = '';
    else if (want && host.firstChild && host.dataset.priv !== String(!!(t && t.priv))) { host.innerHTML = startPage(t); bindStart(); }
    host.dataset.priv = String(!!(t && t.priv));
    VM.updateHole();
  };

  function startPage(t) {
    const priv = !!(t && t.priv);
    const fav = ((native('bm.list') || {}).items || []).slice(0, 8);
    return `<div class="start ${priv ? 'priv' : ''}">${VM.logo(64)}<h2>${priv ? 'Modo privado' : 'VidMax'}</h2><p class="sub muted">${priv ? 'O histórico não é guardado neste separador.' : 'Navegue e descarregue o que o site permitir.'}</p>
<div class="search glass">${icon('search')}<input id="startIn" type="text" enterkeyhint="go" autocomplete="off" autocapitalize="off" placeholder="Pesquisar ou escrever endereço"><button class="mini act pri" data-act="startGo" style="width:40px;height:40px">${icon('fwd')}</button></div>
${fav.length ? `<h3 class="sec">Favoritos</h3><div class="favs">${fav.map(f => `<button class="fav" data-act="openUrl" data-u="${esc(f.url)}"><i>${esc((VM.host(f.url)[0] || '?').toUpperCase())}</i><span>${esc(f.title || VM.host(f.url))}</span></button>`).join('')}</div>` : ''}
<h3 class="sec">Plataformas</h3><div class="chips">${VM.PLATFORMS.map(p => `<button class="pchip" data-act="openUrl" data-u="${esc(p.u)}"><i style="background:${p.c}">${p.l}</i>${p.n}</button>`).join('')}</div>
${priv ? `<div class="card privnote">${icon('mask')} Os sites ainda veem o seu IP e os cookies são partilhados com os separadores normais. Os downloads concluídos ficam guardados.</div>` : ''}</div>`;
  }
  function bindStart() {
    const i = $('#startIn'); if (i) i.addEventListener('keydown', e => { if (e.key === 'Enter') VM.act.startGo(); });
  }

  VM.act.startGo = () => { const v = ($('#startIn').value || '').trim(); if (v) native('br.go', { text: v }); };
  VM.act.bBack = () => native('br.back');
  VM.act.bFwd = () => native('br.forward');
  VM.act.bReload = () => native('br.reload');
  VM.act.bAddr = () => {
    const t = activeTab(), a = $('#bAddr');
    if (a.querySelector('input')) return;
    a.innerHTML = `<input type="url" inputmode="url" enterkeyhint="go" autocomplete="off" autocapitalize="off" spellcheck="false">`;
    const i = a.querySelector('input'); i.value = t ? t.url : ''; i.focus(); i.select();
    i.addEventListener('keydown', e => { if (e.key === 'Enter') { const v = i.value.trim(); i.blur(); if (v) native('br.go', { text: v }); } });
    i.addEventListener('blur', () => { setTimeout(() => { if (a.querySelector('input')) { a.innerHTML = `${icon('lock')}<span>${esc(disp(activeTab()))}</span>`; } }, 80); });
  };
  VM.act.bScan = () => {
    const rid = String(Date.now());
    VM.optLoading(rid, 'A procurar multimédia na página…');
    native('br.scan', { rid });
  };

  // Separadores
  VM.act.bTabs = () => {
    const L = VM.full('', null);
    function draw() {
      const b = S.browser;
      L.set(`<div class="thead"><h2>Separadores (${b.tabs.length})</h2><button class="btn sm" data-act="tabsDone">Concluído</button></div>
<div class="row-btns" style="margin-top:12px"><button class="btn" data-act="tabNew">${icon('plus')} Novo</button><button class="btn" data-act="tabNewPriv">${icon('mask')} Privado</button></div>
<div class="tgrid">${b.tabs.map(t => `<div class="tcard ${t.id === b.active ? 'on' : ''} ${t.priv ? 'priv' : ''}" data-act="tabPick" data-id="${t.id}"><b>${t.priv ? '🕶 ' : ''}${esc(t.title || (t.url ? VM.host(t.url) : 'Novo separador'))}</b><small>${esc(t.url ? VM.host(t.url) : '—')}</small><span class="x" data-act="tabClose" data-id="${t.id}">${icon('x')}</span></div>`).join('')}</div>
<button class="btn danger big" data-act="tabAll" style="margin-top:18px">Fechar todos</button>`);
    }
    L.el.firstElementChild.classList.add('tabsview');
    draw(); VM.tabsLayer = { L, draw };
  };
  const closeTabs = () => { if (VM.tabsLayer) { VM.tabsLayer.L.close(); VM.tabsLayer = null; } };
  VM.act.tabsDone = closeTabs;
  VM.act.tabNew = () => { native('br.newTab', { priv: false }); closeTabs(); };
  VM.act.tabNewPriv = () => { native('br.newTab', { priv: true }); closeTabs(); };
  VM.act.tabPick = (d, el, e) => { if (e.target.closest('.x')) return; native('br.switch', { id: +d.id }); closeTabs(); };
  VM.act.tabClose = (d, el, e) => { e.stopPropagation(); native('br.close', { id: +d.id }); };
  VM.act.tabAll = () => { native('br.closeAll'); closeTabs(); };
  VM.on('browser', () => { if (VM.tabsLayer && VM.layers.indexOf(VM.tabsLayer.L) >= 0) VM.tabsLayer.draw(); });

  // Menu
  VM.act.bMenu = () => {
    const t = activeTab(), bm = S.browser.bookmarked, has = t && t.url;
    const L = VM.sheet(`<div class="mgrid">
<button class="mi" data-act="mNewTab">${icon('plus')}Novo separador</button>
<button class="mi" data-act="mNewPriv">${icon('mask')}Separador privado</button>
<button class="mi" data-act="mHome">${icon('home')}Página inicial</button>
<button class="mi" data-act="mBm" ${has ? '' : 'disabled'}>${icon('star')}${bm ? 'Remover favorito' : 'Adicionar favorito'}</button>
<button class="mi" data-act="mFavs">${icon('star')}Favoritos</button>
<button class="mi" data-act="mHist">${icon('clock')}Histórico</button>
<button class="mi" data-act="mAnalyze" ${has ? '' : 'disabled'}>${icon('download')}Descarregar página</button>
<button class="mi" data-act="mCopy" ${has ? '' : 'disabled'}>${icon('copy')}Copiar link</button>
<button class="mi" data-act="mShare" ${has ? '' : 'disabled'}>${icon('share')}Partilhar</button>
<button class="mi" data-act="mExt" ${has ? '' : 'disabled'}>${icon('external')}Abrir noutra app</button>
<button class="mi" data-act="mDl">${icon('download')}Downloads</button></div>`);
    VM.menuLayer = L;
  };
  const cm = () => { if (VM.menuLayer) { VM.menuLayer.close(); VM.menuLayer = null; } };
  const cur = () => (native('br.current') || {});
  VM.act.mNewTab = () => { cm(); native('br.newTab', { priv: false }); };
  VM.act.mNewPriv = () => { cm(); native('br.newTab', { priv: true }); };
  VM.act.mHome = () => { cm(); native('br.home'); };
  VM.act.mBm = () => { cm(); const c = cur(); const r = native('bm.toggle', { url: c.url, title: c.title }); VM.toast(r && r.added ? 'Adicionado aos favoritos' : 'Removido dos favoritos'); };
  VM.act.mFavs = () => { cm(); VM.go('more', 'favorites'); };
  VM.act.mHist = () => { cm(); VM.go('more', 'history'); };
  VM.act.mAnalyze = () => { cm(); const c = cur(); if (c.url) VM.startAnalyze(c.url); };
  VM.act.mCopy = () => { cm(); native('ui.copy', { text: cur().url }); };
  VM.act.mShare = () => { cm(); native('ui.share', { text: cur().url }); };
  VM.act.mExt = () => { cm(); native('ui.external', { url: cur().url }); };
  VM.act.mDl = () => { cm(); VM.go('downloads'); };

  VM.on('browser', st => { S.browser = st; VM.patchBrowser(); });

  let holeRaf = 0;
  VM.updateHole = function () {
    cancelAnimationFrame(holeRaf);
    holeRaf = requestAnimationFrame(() => {
      let r = null, ex = null;
      const h = $('#hole');
      if (S.route === 'browser' && h && VM.layers.length === 0 && !isBlank()) {
        const b = h.getBoundingClientRect();
        r = [b.left, b.top, b.right, b.bottom];
        const f = $('#fab');
        if (f) { const fb = f.getBoundingClientRect(); ex = [fb.left - 8, fb.top - 8, fb.right + 8, fb.bottom + 8]; }
      }
      native('ui.hole', { r, ex });
    });
  };
  window.addEventListener('resize', () => VM.updateHole());
})();
