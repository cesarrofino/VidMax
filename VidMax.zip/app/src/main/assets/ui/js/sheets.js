(function () {
  const { S, $, esc, icon, native } = VM;
  function openLayer(kind, html, onClose) {
    const el = document.createElement('div');
    el.className = 'scrim ' + kind;
    el.innerHTML = kind === 'modal' ? `<div class="modal box glass">${html}</div>` : kind === 'full' ? `<div class="panel">${html}</div>` : `<div class="sheet glass"><div class="grab"></div><div class="sbody">${html}</div></div>`;
    el.addEventListener('click', e => { if (e.target === el && kind !== 'full') L.close(); });
    $('#layer').appendChild(el);
    requestAnimationFrame(() => el.classList.add('in'));
    const L = {
      el, kind,
      set(h) { const b = $('.sbody', el) || el.firstElementChild; b.innerHTML = h; },
      close() {
        const i = VM.layers.indexOf(L); if (i < 0) return;
        VM.layers.splice(i, 1); el.classList.remove('in'); setTimeout(() => el.remove(), 230);
        if (onClose) onClose(); VM.updateHole && VM.updateHole();
      }
    };
    VM.layers.push(L); VM.updateHole && VM.updateHole();
    return L;
  }
  VM.sheet = (h, c) => openLayer('sheet', h, c);
  VM.full = (h, c) => openLayer('full', h, c);
  VM.closeTop = () => { const l = VM.layers[VM.layers.length - 1]; if (l) { l.close(); return true; } return false; };

  VM.confirm = function (o) {
    return new Promise(res => {
      const L = openLayer('modal', `<h3>${esc(o.title)}</h3><p>${esc(o.text || '')}</p><div class="row-btns"><button class="btn" data-act="mNo">${esc(o.no || 'Cancelar')}</button><button class="btn ${o.danger ? 'danger' : 'primary'}" data-act="mYes">${esc(o.yes || 'OK')}</button></div>`, () => res(false));
      VM.act.mNo = () => L.close();
      VM.act.mYes = () => { res(true); const i = VM.layers.indexOf(L); if (i >= 0) { L.close(); } };
    });
  };
  VM.info = function (title, text) {
    const L = openLayer('modal', `<h3>${esc(title)}</h3><p>${esc(text)}</p><div class="row-btns"><button class="btn primary" data-act="mNo">OK</button></div>`);
    VM.act.mNo = () => L.close();
  };
  VM.toast = function (msg) {
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; $('#layer').appendChild(t);
    requestAnimationFrame(() => t.classList.add('in'));
    setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 300); }, 2400);
  };
  VM.success = function (msg) {
    const d = document.createElement('div'); d.className = 'success';
    d.innerHTML = `<div>${icon('check')}<span>${esc(msg)}</span></div>`; $('#layer').appendChild(d);
    setTimeout(() => d.remove(), 1500);
  };

  // ---------- Folha de opções de download ----------
  VM.opt = null;
  VM.optLoading = function (rid, label) {
    if (VM.opt) VM.opt.L.close();
    const L = VM.sheet(`<div class="spin"></div><p class="muted" style="text-align:center;margin:0 0 14px">${esc(label || 'A analisar o link…')}</p>`, () => { VM.opt = null; });
    VM.opt = { rid, L, res: null };
  };
  function head(res) {
    const th = res.thumb ? `<img src="${esc(res.thumb)}" referrerpolicy="no-referrer">` : '';
    const title = res.title || res.platform || VM.host(res.url);
    return `<div class="ohead"><div class="thumb">${icon('video')}${th}</div><div style="min-width:0"><b>${esc(title)}</b><span class="tag">${esc(res.platform || VM.host(res.url))}</span></div></div>`;
  }
  function rows(res) {
    return res.options.map((o, i) => {
      const label = o.quality || (o.kind === 'audio' ? 'Áudio' : o.kind === 'video' ? 'Original' : 'Ficheiro');
      const size = o.size > 0 ? ' · ' + (o.sizeEst ? '~' : '') + VM.fmtBytes(o.size) : '';
      return `<label class="opt"><input type="checkbox" data-i="${i}" ${i === 0 ? 'checked' : ''}><span class="chk">${icon('check')}</span><span class="om"><b>${esc(label)}</b><small>${esc((o.ext || '').toUpperCase())}${size}${o.note ? ' · ' + esc(o.note) : ''}</small></span><span class="ok">${icon(VM.kindIcon(o.kind))}</span></label>`;
    }).join('');
  }
  VM.optShow = function (res) {
    if (res.rid && (!VM.opt || VM.opt.rid !== res.rid)) return; // resposta antiga
    if (!VM.opt) { const L = VM.sheet('', () => { VM.opt = null; }); VM.opt = { rid: null, L, res: null }; }
    VM.opt.res = res;
    let h;
    if (!res.ok) h = `<div class="empty"><div class="eic">${icon('alert')}</div><b>Não foi possível continuar</b><p>${esc(res.message)}</p></div>`;
    else if (res.restricted) h = head(res) + `<div class="note">${icon('shield')}<p>${esc(res.message)}</p></div><div class="row-btns"><button class="btn primary" data-act="openInVidmax" data-url="${esc(res.url)}">${icon('globe')} Abrir no navegador</button><button class="btn" data-act="openExt" data-url="${esc(res.url)}">${icon('external')} Site oficial</button></div>`;
    else if (!res.options.length) h = head(res) + `<div class="empty"><div class="eic">${icon('inbox')}</div><b>Nada para descarregar</b><p>${esc(res.message || 'Nenhum conteúdo descarregável encontrado.')}</p></div>`;
    else h = head(res) + `<div id="optRows">${rows(res)}</div><button class="btn primary big" id="optGo" data-act="optStart" style="margin-top:8px">${icon('download')} <span id="optN">Descarregar (1)</span></button>`;
    VM.opt.L.set(h);
  };
  document.addEventListener('change', e => {
    if (!VM.opt || !e.target.closest('#optRows')) return;
    const n = document.querySelectorAll('#optRows input:checked').length;
    $('#optN').textContent = n ? `Descarregar (${n})` : 'Selecione um item';
    $('#optGo').disabled = !n;
  });
  VM.act.optStart = () => {
    if (!VM.opt || !VM.opt.res) return;
    const sel = Array.from(document.querySelectorAll('#optRows input:checked')).map(i => VM.opt.res.options[+i.dataset.i]);
    if (!sel.length) return;
    const r = native('dl.start', { options: sel });
    VM.opt.L.close();
    if (r && r.ok) VM.success(sel.length > 1 ? sel.length + ' downloads' : 'Download iniciado');
    else VM.toast('Não foi possível iniciar o download');
  };
  VM.act.openInVidmax = d => { if (VM.opt) VM.opt.L.close(); native('br.newTab', { url: d.url }); VM.go('browser'); };
  VM.act.openExt = d => native('ui.external', { url: d.url });
  VM.startAnalyze = function (url) {
    const rid = String(Date.now());
    VM.optLoading(rid);
    native('dl.analyze', { url, rid });
  };
  VM.on('analyze', r => VM.optShow(r));
  VM.on('options', r => {
    if (!r.rid && !VM.opt) { VM.optShow(r); return; }
    VM.optShow(r);
  });
})();
