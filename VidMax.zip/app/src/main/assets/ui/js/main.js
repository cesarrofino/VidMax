(function () {
  const { S, $, $$, esc, icon, native } = VM;
  const NAV = [['home', 'Início', 'home'], ['downloads', 'Downloads', 'download'], ['browser', 'Navegador', 'globe'], ['more', 'Mais', 'grid']];

  function drawNav() {
    const act = S.downloads.filter(d => d.status === 'downloading' || d.status === 'queued').length;
    $('#nav').innerHTML = NAV.map(n => `<button data-act="nav" data-r="${n[0]}" class="${S.route === n[0] ? 'on' : ''}"><span class="pill">${icon(n[2])}</span>${n[1]}${n[0] === 'downloads' && act ? `<span class="badge">${act}</span>` : ''}</button>`).join('');
  }

  VM.render = function () {
    document.documentElement.classList.toggle('rb', S.route === 'browser');
    const view = $('#view');
    switch (S.route) {
      case 'downloads': view.innerHTML = VM.renderDownloads(); VM.patchDownloads(); break;
      case 'browser': view.innerHTML = VM.renderBrowser(); VM.patchBrowser(); break;
      case 'more': view.innerHTML = VM.renderMore(); VM.afterMore(); break;
      default: view.innerHTML = VM.renderHome(); VM.afterHome();
    }
    drawNav();
    native('ui.route', { route: S.route });
    VM.updateHole();
  };

  VM.go = function (route, sub) {
    while (VM.layers.length) VM.layers[VM.layers.length - 1].close();
    S.route = route; S.sub = sub || null; VM.render();
  };
  VM.act.nav = d => { if (S.route === d.r && !S.sub) return; VM.go(d.r, null); };

  VM.back = function () {
    if (VM.layers.length) { VM.closeTop(); return true; }
    if (S.route === 'browser') {
      if (S.browser.canBack) { native('br.back'); return true; }
      if (!VM.isBlankTab()) { native('br.home'); return true; }
      VM.go('home'); return true;
    }
    if (S.route === 'more' && S.sub) { VM.go('more', null); return true; }
    if (S.route !== 'home') { VM.go('home'); return true; }
    return false;
  };

  // ---------- Eventos nativos ----------
  VM.on('downloads', r => {
    S.downloads = (r && r.items) || [];
    drawNav();
    if (S.route === 'downloads') VM.patchDownloads();
    else if (S.route === 'home') VM.patchRecent();
    else if (S.route === 'more' && ['files', 'player', 'storage'].includes(S.sub) && !VM.layers.length) {
      const y = $('.page') ? $('.page').scrollTop : 0; VM.render(); const p = $('.page'); if (p) p.scrollTop = y;
    }
  });
  VM.on('settings', r => { VM.applySettings(r); if (S.route === 'more') VM.render(); });
  VM.on('route', r => { if (r && r.route) VM.go(r.route === 'downloads' ? 'downloads' : r.route, null); });
  VM.on('shared', r => {
    if (!r || !r.url) return;
    if (r.mode === 'browse') { VM.go('browser'); return; }
    VM.go('home'); S.link = r.url; const li = $('#linkIn'); if (li) li.value = r.url;
    VM.startAnalyze(r.url);
  });

  // ---------- Arranque ----------
  function boot() {
    $('#splashLogo').innerHTML = VM.logo(96);
    if (!window.Android) {
      $('#splash').classList.add('hide');
      $('#view').innerHTML = '<div class="page"><div class="empty"><div class="eic">' + icon('alert') + '</div><b>Abra o VidMax no Android</b><p>Esta interface precisa da aplicação VidMax para funcionar.</p></div></div>';
      return;
    }
    const init = native('settings.get');
    VM.applySettings(init);
    const st = native('br.state'); if (st && st.tabs) S.browser = st;
    const dl = native('dl.list'); if (dl) S.downloads = dl.items || [];
    VM.render();
    native('ui.ready');
    setTimeout(() => $('#splash').classList.add('hide'), 650);
    setTimeout(() => { const s = $('#splash'); if (s) s.remove(); }, 1300);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
