(function () {
  const { S, $, $$, esc, icon, native } = VM;
  const row = (ic, t, s, act, extra) => `<button class="mrow" data-act="${act}" ${extra || ''}><span class="ri">${icon(ic)}</span><span class="rt"><b>${t}</b>${s ? `<small>${s}</small>` : ''}</span>${icon('chevron')}</button>`;
  const tog = (ic, t, s, key, on) => `<div class="mrow"><span class="ri">${icon(ic)}</span><span class="rt"><b>${t}</b>${s ? `<small>${s}</small>` : ''}</span><label class="switch"><input type="checkbox" data-set="${key}" ${on ? 'checked' : ''}><i></i></label></div>`;
  const sub = (title, body, extra) => `<div class="page"><div class="subhead"><button class="icon-btn glass" data-act="subBack" aria-label="Voltar">${icon('back')}</button><h2>${title}</h2>${extra || ''}</div>${body}</div>`;

  VM.renderMore = function () {
    switch (S.sub) {
      case 'history': return renderHistory();
      case 'favorites': return renderFavs();
      case 'files': return renderFiles('files');
      case 'player': return renderFiles('player');
      case 'settings': return renderSettings();
      case 'storage': return renderStorage();
      case 'about': return renderAbout();
    }
    const th = S.settings.theme;
    return `<div class="page"><div class="top"><h2>Mais</h2></div>
<div class="seg glass"><button data-act="setTheme" data-v="auto" class="${th === 'auto' ? 'on' : ''}">Auto</button><button data-act="setTheme" data-v="light" class="${th === 'light' ? 'on' : ''}">${icon('sun')}</button><button data-act="setTheme" data-v="dark" class="${th === 'dark' ? 'on' : ''}">${icon('moon')}</button></div>
${row('clock', 'Histórico', 'Páginas visitadas', 'subHistory')}${row('star', 'Favoritos', 'Páginas guardadas', 'subFavorites')}
${row('folder', 'Ficheiros descarregados', 'Vídeos, músicas e outros', 'subFiles')}${row('play', 'Reprodutor', 'Reproduzir vídeos e músicas', 'subPlayer')}
${row('settings', 'Definições', 'Tema, downloads, privacidade', 'subSettings')}${row('drive', 'Armazenamento', 'Espaço usado e cache', 'subStorage')}
${row('info', 'Sobre o VidMax', 'Versão ' + esc(S.version), 'subAbout')}${row('share', 'Partilhar aplicação', '', 'shareApp')}</div>`;
  };
  VM.afterMore = function () {
    if (S.sub === 'storage') loadStorage();
    $$('[data-set]').forEach(i => i.addEventListener('change', () => {
      const k = i.dataset.set; const r = native('settings.set', { k, v: i.checked });
      if (r) { S.settings = r.settings; }
      if (k === 'notifications' && i.checked) native('perm.notifications');
    }));
  };
  ['History', 'Favorites', 'Files', 'Player', 'Settings', 'Storage', 'About'].forEach(n => { VM.act['sub' + n] = () => VM.go('more', n.toLowerCase()); });
  VM.act.subBack = () => VM.go('more', null);
  VM.act.shareApp = () => native('app.shareApp');
  VM.act.setTheme = d => applyTheme(d.v);
  function applyTheme(v) {
    const r = native('settings.set', { k: 'theme', v }); if (!r) return;
    S.settings = r.settings; S.effective = r.effective; document.documentElement.dataset.theme = r.effective;
    if (S.route === 'more') VM.render();
  }
  VM.applySettings = function (r) { if (!r) return; S.settings = r.settings; S.effective = r.effective; S.version = r.version || S.version; document.documentElement.dataset.theme = r.effective; };

  // Histórico
  function renderHistory() {
    const items = (native('hist.list') || {}).items || [];
    let body;
    if (!items.length) body = `<div class="empty"><div class="eic">${icon('clock')}</div><b>Histórico vazio</b><p>As páginas visitadas aparecem aqui.</p></div>`;
    else {
      let last = '';
      body = items.slice(0, 300).map(h => {
        const day = new Date(h.t).toLocaleDateString('pt-PT', { weekday: 'long', day: 'numeric', month: 'long' });
        const head = day !== last ? `<div class="dayh">${esc(day)}</div>` : ''; last = day;
        return head + `<div class="hitem"><button class="ht" data-act="openUrl" data-u="${esc(h.url)}" style="text-align:left;flex:1;min-width:0"><b>${esc(h.title || VM.host(h.url))}</b><small>${esc(h.url)}</small></button><button class="act dng" data-act="histDel" data-u="${esc(h.url)}" data-t="${h.t}">${icon('x')}</button></div>`;
      }).join('');
    }
    return sub('Histórico', body, items.length ? `<button class="btn sm danger" data-act="histClear">Limpar</button>` : '');
  }
  VM.act.histDel = d => { native('hist.remove', { url: d.u, t: +d.t }); VM.render(); };
  VM.act.histClear = async () => { if (await VM.confirm({ title: 'Limpar histórico?', text: 'Todas as páginas visitadas serão removidas.', yes: 'Limpar', danger: true })) { native('hist.clear'); VM.render(); VM.toast('Histórico limpo'); } };

  // Favoritos
  function renderFavs() {
    const items = (native('bm.list') || {}).items || [];
    const body = items.length ? items.map(f => `<div class="hitem"><button class="ht" data-act="openUrl" data-u="${esc(f.url)}" style="text-align:left;flex:1;min-width:0"><b>${esc(f.title || VM.host(f.url))}</b><small>${esc(f.url)}</small></button><button class="act dng" data-act="bmDel" data-u="${esc(f.url)}">${icon('x')}</button></div>`).join('')
      : `<div class="empty"><div class="eic">${icon('star')}</div><b>Sem favoritos</b><p>No navegador, abra o menu e escolha “Adicionar favorito”.</p></div>`;
    return sub('Favoritos', body);
  }
  VM.act.bmDel = d => { native('bm.remove', { url: d.u }); VM.render(); };

  // Ficheiros / Reprodutor
  function renderFiles(mode) {
    const f = S.filter;
    let items = S.downloads.filter(d => d.status === 'completed').sort((a, b) => b.completed - a.completed);
    if (mode === 'player') items = items.filter(d => d.kind === 'video' || d.kind === 'audio');
    else if (f !== 'all') items = items.filter(d => d.kind === f);
    const chips = mode === 'files' ? `<div class="fchips">${[['all', 'Todos'], ['video', 'Vídeos'], ['audio', 'Músicas'], ['file', 'Outros']].map(c => `<button data-act="fFilter" data-f="${c[0]}" class="${f === c[0] ? 'on' : ''}">${c[1]}</button>`).join('')}</div>` : '';
    const body = items.length ? `<div class="list" id="fileList">${items.map(d => `<div class="item card"><div class="thumb k-${d.kind}">${icon(VM.kindIcon(d.kind))}${d.thumb ? `<img src="${esc(d.thumb)}" referrerpolicy="no-referrer">` : ''}</div><div class="imeta"><div class="iname">${esc(d.title)}</div><div class="tags"><span class="tag">${esc(d.ext.toUpperCase())}</span><span class="tag">${VM.fmtBytes(d.total)}</span></div>
<div class="acts">${d.kind === 'video' || d.kind === 'audio' ? `<button class="act pri" data-act="dlPlay" data-id="${d.id}">${icon('play')}</button>` : ''}<button class="act" data-act="dlOpen" data-id="${d.id}">${icon('external')}</button><button class="act" data-act="dlShare" data-id="${d.id}">${icon('share')}</button><button class="act" data-act="dlWhere" data-id="${d.id}">${icon('folder')}</button><button class="act dng" data-act="dlDelete" data-id="${d.id}">${icon('trash')}</button></div></div></div>`).join('')}</div>`
      : `<div class="empty"><div class="eic">${icon(mode === 'player' ? 'play' : 'inbox')}</div><b>${mode === 'player' ? 'Nada para reproduzir' : 'Sem ficheiros'}</b><p>Os vídeos e músicas descarregados aparecem aqui.</p></div>`;
    return sub(mode === 'player' ? 'Reprodutor' : 'Ficheiros', chips + body);
  }
  VM.act.fFilter = d => { S.filter = d.f; VM.render(); };

  // Definições
  function renderSettings() {
    const s = S.settings, eng = { duckduckgo: 'DuckDuckGo', google: 'Google', bing: 'Bing' };
    return sub('Definições', `
<div class="seg glass"><button data-act="setTheme" data-v="auto" class="${s.theme === 'auto' ? 'on' : ''}">Automático</button><button data-act="setTheme" data-v="light" class="${s.theme === 'light' ? 'on' : ''}">Claro</button><button data-act="setTheme" data-v="dark" class="${s.theme === 'dark' ? 'on' : ''}">Escuro</button></div>
<button class="mrow" data-act="pickFolder"><span class="ri">${icon('folder')}</span><span class="rt"><b>Pasta de downloads</b><small>${s.folder ? esc(s.folder) : 'Padrão: Filmes, Música e Download › VidMax'}</small></span>${icon('chevron')}</button>
${s.folder ? `<button class="btn sm" data-act="resetFolder" style="margin:-2px 0 10px">Repor pasta padrão</button>` : ''}
<div class="mrow"><span class="ri">${icon('download')}</span><span class="rt"><b>Downloads simultâneos</b><small>Máximo em paralelo</small></span><div class="stepper"><button data-act="maxDec">−</button><b id="maxN">${s.maxConcurrent}</b><button data-act="maxInc">+</button></div></div>
${tog('bell', 'Notificações', 'Progresso e conclusão', 'notifications', s.notifications)}
${tog('play', 'Reprodução automática', 'Iniciar ao abrir um ficheiro', 'autoplay', s.autoplay)}
${tog('clock', 'Guardar histórico', 'Páginas visitadas (não em modo privado)', 'saveHistory', s.saveHistory)}
<button class="mrow" data-act="pickEngine"><span class="ri">${icon('search')}</span><span class="rt"><b>Motor de pesquisa</b><small>${eng[s.searchEngine] || 'DuckDuckGo'}</small></span>${icon('chevron')}</button>
<h3 class="sec">Privacidade e dados</h3>
<button class="mrow" data-act="clrHist"><span class="ri">${icon('trash')}</span><span class="rt"><b>Limpar histórico</b></span></button>
<button class="mrow" data-act="clrCache"><span class="ri">${icon('refresh')}</span><span class="rt"><b>Limpar cache</b></span></button>
<button class="mrow" data-act="clrCookies"><span class="ri">${icon('shield')}</span><span class="rt"><b>Limpar cookies e dados de sites</b><small>Termina as sessões nos sites</small></span></button>
<div class="note">${icon('shield')}<p>O VidMax não guarda palavras-passe, não recolhe dados pessoais e não tem anúncios nem análises. Tudo fica no seu dispositivo.</p></div>
${row('drive', 'Gestão de armazenamento', '', 'subStorage')}${row('info', 'Sobre o VidMax', '', 'subAbout')}`);
  }
  VM.act.pickFolder = () => native('settings.pickFolder');
  VM.act.resetFolder = () => { const r = native('settings.resetFolder'); VM.applySettings(r); VM.render(); };
  const setMax = v => { v = Math.max(1, Math.min(5, v)); const r = native('settings.set', { k: 'maxConcurrent', v }); if (r) { S.settings = r.settings; $('#maxN').textContent = v; } };
  VM.act.maxDec = () => setMax((S.settings.maxConcurrent || 2) - 1);
  VM.act.maxInc = () => setMax((S.settings.maxConcurrent || 2) + 1);
  VM.act.pickEngine = () => {
    const L = VM.sheet(`<h3 style="margin:0 0 12px">Motor de pesquisa</h3>${['duckduckgo|DuckDuckGo', 'google|Google', 'bing|Bing'].map(x => { const [k, n] = x.split('|'); return `<button class="mrow" data-act="setEngine" data-v="${k}"><span class="ri">${icon('search')}</span><span class="rt"><b>${n}</b></span>${S.settings.searchEngine === k ? icon('check') : ''}</button>`; }).join('')}`);
    VM.engLayer = L;
  };
  VM.act.setEngine = d => { const r = native('settings.set', { k: 'searchEngine', v: d.v }); if (r) S.settings = r.settings; if (VM.engLayer) VM.engLayer.close(); VM.render(); };
  VM.act.clrHist = VM.act.histClear;
  VM.act.clrCache = () => { const r = native('cache.clear'); VM.toast('Cache limpa · ' + VM.fmtBytes(r ? r.freed : 0) + ' libertados'); };
  VM.act.clrCookies = async () => { if (await VM.confirm({ title: 'Limpar dados de sites?', text: 'Vai terminar sessões em todos os sites.', yes: 'Limpar', danger: true })) { native('cookies.clear'); VM.toast('Cookies e dados removidos'); } };

  // Armazenamento
  function renderStorage() { return sub('Armazenamento', `<div id="stBox"><div class="spin"></div></div>`); }
  function loadStorage() {
    const r = native('storage.info'); const box = $('#stBox'); if (!r || !box) return;
    const used = r.video + r.audio + r.other + r.partial, tot = Math.max(1, used);
    const seg = (v, c) => `<i style="width:${v / tot * 100}%;background:${c}"></i>`;
    box.innerHTML = `<div class="card" style="padding:16px"><b>Espaço usado pelo VidMax</b><div style="font-size:26px;font-weight:800;margin:6px 0">${VM.fmtBytes(used)}</div>
<div class="sbar">${seg(r.video, 'var(--primary)')}${seg(r.audio, 'var(--secondary)')}${seg(r.other, 'var(--accent)')}${seg(r.partial, '#8A94B8')}</div>
<div class="legend"><span style="--c:var(--primary)">Vídeos ${VM.fmtBytes(r.video)} (${r.videoCount})</span><span style="--c:var(--secondary)">Músicas ${VM.fmtBytes(r.audio)} (${r.audioCount})</span><span style="--c:var(--accent)">Outros ${VM.fmtBytes(r.other)} (${r.otherCount})</span><span style="--c:#8A94B8">Em curso ${VM.fmtBytes(r.partial)}</span></div></div>
<div class="card" style="padding:16px;margin-top:12px"><b>Dispositivo</b><p class="muted" style="margin:6px 0 0">Livre: ${VM.fmtBytes(r.free)} de ${VM.fmtBytes(r.total)}</p></div>
<div class="card" style="padding:16px;margin-top:12px"><b>Cache</b><p class="muted" style="margin:6px 0 10px">${VM.fmtBytes(r.cache)}</p><button class="btn" data-act="clrCache2">Limpar cache</button></div>`;
  }
  VM.act.clrCache2 = () => { VM.act.clrCache(); loadStorage(); };

  function renderAbout() {
    return sub('Sobre', `<div class="about">${VM.logo(84)}<h2 style="margin-top:8px">VidMax</h2><div class="muted">Versão ${esc(S.version)}</div>
<p>Baixe vídeos e músicas, navegue na Internet e organize os seus downloads num único lugar.</p>
<p><b>Respeito pelas plataformas.</b> O VidMax descarrega ficheiros que os servidores disponibilizam (links diretos, HTML5, HLS sem encriptação). Não contorna DRM, paywalls, autenticação nem restrições. YouTube, TikTok, Instagram, Facebook e X são reconhecidos, mas o descarregamento deve ser feito pelas opções oficiais de cada plataforma.</p>
<p>Descarregue apenas conteúdos que tem direito de guardar.</p></div>`);
  }
})();
