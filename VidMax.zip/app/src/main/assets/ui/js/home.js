(function () {
  const { S, $, $$, esc, icon, native } = VM;
  const PLATFORMS = [
    { n: 'YouTube', u: 'https://m.youtube.com/', c: '#FF2D55', l: 'Y' }, { n: 'TikTok', u: 'https://www.tiktok.com/', c: '#12B5C8', l: 'T' },
    { n: 'Instagram', u: 'https://www.instagram.com/', c: '#D6249F', l: 'I' }, { n: 'Facebook', u: 'https://m.facebook.com/', c: '#1877F2', l: 'F' },
    { n: 'X', u: 'https://x.com/', c: '#5B6B85', l: 'X' }, { n: 'Vimeo', u: 'https://vimeo.com/', c: '#1AB7EA', l: 'V' },
    { n: 'Dailymotion', u: 'https://www.dailymotion.com/', c: '#0066DC', l: 'D' }
  ];
  VM.PLATFORMS = PLATFORMS;

  VM.renderHome = function () {
    return `<div class="page home">
<div class="top"><div class="brand">${VM.logo(36)}<span>VidMax</span></div><button class="icon-btn glass" data-act="openSettings" aria-label="Definições">${icon('settings')}</button></div>
<section class="hero glass"><h1>Baixe vídeos e músicas</h1><p class="muted" style="margin:0;font-size:13.5px">Cole um link, partilhe a partir de outra app ou navegue e descarregue.</p>
<div class="linkbox">${icon('link')}<input id="linkIn" type="url" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Cole aqui o link" value="${esc(S.link)}"><button class="mini" data-act="paste" aria-label="Colar">${icon('clipboard')}</button></div>
<button class="btn primary big" data-act="analyze">${icon('download')} Baixar</button></section>
<h3 class="sec">Plataformas</h3>
<div class="chips">${PLATFORMS.map(p => `<button class="pchip" data-act="openPlat" data-u="${esc(p.u)}"><i style="background:${p.c}">${p.l}</i>${p.n}</button>`).join('')}</div>
<h3 class="sec">Navegador</h3>
<div class="card bcard"><div class="search">${icon('search')}<input id="homeSearch" type="text" inputmode="search" enterkeyhint="go" autocomplete="off" autocapitalize="off" placeholder="Pesquisar ou escrever endereço"><button class="mini act pri" data-act="homeGo" style="width:40px;height:40px">${icon('fwd')}</button></div><div id="homeFavs"></div></div>
<h3 class="sec">Downloads recentes<a data-act="goDownloads">Ver tudo</a></h3>
<div id="recent" class="list"></div></div>`;
  };

  VM.afterHome = function () {
    const li = $('#linkIn');
    li.addEventListener('input', () => { S.link = li.value; });
    li.addEventListener('keydown', e => { if (e.key === 'Enter') VM.act.analyze(); });
    const hs = $('#homeSearch');
    hs.addEventListener('keydown', e => { if (e.key === 'Enter') VM.act.homeGo(); });
    const b = native('bm.list');
    const items = (b && b.items || []).slice(0, 4);
    $('#homeFavs').innerHTML = items.length ? `<div class="favs">${items.map(f => `<button class="fav" data-act="openUrl" data-u="${esc(f.url)}"><i>${esc((VM.host(f.url)[0] || '?').toUpperCase())}</i><span>${esc(f.title || VM.host(f.url))}</span></button>`).join('')}</div>` : '';
    VM.patchRecent();
  };

  VM.patchRecent = function () {
    const box = $('#recent'); if (!box) return;
    const items = S.downloads.slice().sort((a, b) => b.created - a.created).slice(0, 4);
    if (!items.length) {
      box.innerHTML = `<div class="empty"><div class="eic">${icon('download')}</div><b>Ainda sem downloads</b><p>Os seus downloads aparecem aqui assim que começar.</p></div>`;
      return;
    }
    box.innerHTML = items.map(d => {
      const th = d.thumb ? `<img src="${esc(d.thumb)}" referrerpolicy="no-referrer">` : '';
      const st = d.status === 'completed' ? 'Concluído · ' + VM.fmtBytes(d.total) : d.status === 'failed' ? 'Falhou' : d.status === 'paused' ? 'Em pausa · ' + d.pct + '%' : d.status === 'queued' ? 'Na fila' : d.pct + '%';
      return `<button class="item card" data-act="goDownloads" style="width:100%;text-align:left"><div class="thumb k-${d.kind}">${icon(VM.kindIcon(d.kind))}${th}</div><div class="imeta"><div class="iname">${esc(d.title)}</div><div class="st" style="margin-top:6px">${esc(st)}</div>${d.status === 'completed' ? '' : `<div class="bar"><i style="width:${d.pct}%"></i></div>`}</div></button>`;
    }).join('');
  };

  VM.act.paste = () => {
    const r = native('ui.clipboard');
    const t = r && r.text ? r.text.trim() : '';
    if (!t) { VM.toast('A área de transferência está vazia'); return; }
    S.link = t; const li = $('#linkIn'); if (li) li.value = t;
  };
  VM.act.analyze = () => {
    const li = $('#linkIn'); const v = (li ? li.value : S.link).trim();
    if (!v) { VM.toast('Cole primeiro um link'); return; }
    VM.startAnalyze(v);
  };
  VM.act.openPlat = d => { native('br.go', { text: d.u }); VM.go('browser'); };
  VM.act.openUrl = d => { native('br.go', { text: d.u }); VM.go('browser'); };
  VM.act.homeGo = () => {
    const v = ($('#homeSearch').value || '').trim(); if (!v) return;
    native('br.go', { text: v }); VM.go('browser');
  };
  VM.act.goDownloads = () => VM.go('downloads');
  VM.act.openSettings = () => VM.go('more', 'settings');
})();
