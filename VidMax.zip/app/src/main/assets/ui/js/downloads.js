(function () {
  const { S, $, $$, esc, icon, native } = VM;

  VM.renderDownloads = function () {
    return `<div class="page dls"><div class="top"><h2>Downloads</h2></div>
<div class="seg glass"><button data-act="dlTab" data-t="active">A descarregar<em id="cA">0</em></button><button data-act="dlTab" data-t="done">Concluídos<em id="cD">0</em></button></div>
<div id="dlList" class="list"></div><div id="dlEmpty"></div></div>`;
  };

  function statusText(d) {
    const sz = d.total > 0 ? `${VM.fmtBytes(d.downloaded)} / ${d.sizeEst ? '~' : ''}${VM.fmtBytes(d.total)}` : VM.fmtBytes(d.downloaded);
    if (d.status === 'queued') return 'Na fila…';
    if (d.status === 'paused') return `Em pausa · ${d.pct}% · ${sz}`;
    if (d.status === 'failed') return d.error || 'Falhou';
    const sp = d.speed > 0 ? ` · ${VM.fmtBytes(d.speed)}/s` : '';
    const eta = d.eta >= 0 && d.speed > 0 ? ` · ${VM.fmtEta(d.eta)}` : '';
    return `${d.pct}%${sp}${eta} · ${sz}`;
  }
  function tags(d) {
    return `<div class="tags"><span class="tag">${esc((d.ext || '').toUpperCase())}</span>${d.quality ? `<span class="tag q">${esc(d.quality)}</span>` : ''}${d.source ? `<span class="tag">${esc(d.source)}</span>` : ''}</div>`;
  }
  function thumb(d) {
    return `<div class="thumb k-${d.kind}">${icon(VM.kindIcon(d.kind))}${d.thumb ? `<img src="${esc(d.thumb)}" referrerpolicy="no-referrer">` : ''}</div>`;
  }
  function activeCard(d) {
    const running = d.status === 'downloading' || d.status === 'queued';
    const indet = d.status === 'downloading' && !d.hls && !(d.total > 0);
    return `<div class="item card" data-id="${d.id}">${thumb(d)}<div class="imeta"><div class="iname">${esc(d.title)}</div>${tags(d)}
<div class="bar ${indet ? 'indet' : ''}"><i style="width:${d.pct}%"></i></div><div class="st ${d.status === 'failed' ? 'err' : ''}">${esc(statusText(d))}</div>
<div class="acts">${running ? `<button class="act" data-act="dlPause" data-id="${d.id}" aria-label="Pausar">${icon('pause')}</button>` : `<button class="act pri" data-act="dlResume" data-id="${d.id}" aria-label="Retomar">${icon(d.status === 'failed' ? 'refresh' : 'play')}</button>`}
<button class="act dng" data-act="dlCancel" data-id="${d.id}" aria-label="Cancelar">${icon('x')}</button></div></div></div>`;
  }
  function doneCard(d) {
    const media = d.kind === 'video' || d.kind === 'audio';
    return `<div class="item card" data-id="${d.id}">${thumb(d)}<div class="imeta"><div class="iname">${esc(d.title)}</div>${tags(d)}
<div class="st">${VM.fmtBytes(d.total)} · ${VM.fmtDate(d.completed)}</div>
<div class="acts">${media ? `<button class="act pri" data-act="dlPlay" data-id="${d.id}" aria-label="Reproduzir">${icon('play')}</button>` : ''}
<button class="act" data-act="dlOpen" data-id="${d.id}" aria-label="Abrir">${icon('external')}</button>
<button class="act" data-act="dlShare" data-id="${d.id}" aria-label="Partilhar">${icon('share')}</button>
<button class="act" data-act="dlWhere" data-id="${d.id}" aria-label="Localização">${icon('folder')}</button>
<button class="act dng" data-act="dlDelete" data-id="${d.id}" aria-label="Eliminar">${icon('trash')}</button></div></div></div>`;
  }

  VM.patchDownloads = function () {
    const box = $('#dlList'); if (!box) return;
    const act = S.downloads.filter(d => d.status !== 'completed').sort((a, b) => a.created - b.created);
    const done = S.downloads.filter(d => d.status === 'completed').sort((a, b) => b.completed - a.completed);
    $('#cA').textContent = act.length; $('#cD').textContent = done.length;
    $$('.seg button').forEach(b => b.classList.toggle('on', b.dataset.t === S.dlTab));
    const items = S.dlTab === 'active' ? act : done;
    const empty = $('#dlEmpty');
    if (!items.length) {
      box.innerHTML = '';
      empty.innerHTML = S.dlTab === 'active'
        ? `<div class="empty"><div class="eic">${icon('download')}</div><b>Sem downloads ativos</b><p>Cole um link na página inicial ou use o botão de download no navegador.</p><button class="btn primary" data-act="goHome">Ir para o início</button></div>`
        : `<div class="empty"><div class="eic">${icon('inbox')}</div><b>Ainda não há ficheiros</b><p>Os downloads concluídos ficam guardados aqui.</p></div>`;
      return;
    }
    empty.innerHTML = '';
    const map = new Map($$(':scope > [data-id]', box).map(e => [e.dataset.id, e]));
    const els = items.map(d => {
      const sig = [S.dlTab, d.status, d.title, d.thumb, d.error, d.total > 0, d.kind].join('|');
      const ex = map.get(d.id); map.delete(d.id);
      if (ex && ex.dataset.sig === sig) {
        const bar = $('.bar i', ex); if (bar) bar.style.width = d.pct + '%';
        const st = $('.st', ex); if (st && S.dlTab === 'active') st.textContent = statusText(d);
        return ex;
      }
      const t = document.createElement('div'); t.innerHTML = S.dlTab === 'active' ? activeCard(d) : doneCard(d);
      const ne = t.firstElementChild; ne.dataset.sig = sig; return ne;
    });
    map.forEach(e => e.remove());
    els.forEach(e => box.appendChild(e));
  };

  VM.act.dlTab = d => { S.dlTab = d.t; VM.patchDownloads(); };
  VM.act.goHome = () => VM.go('home');
  VM.act.dlPause = d => native('dl.pause', { id: d.id });
  VM.act.dlResume = d => native('dl.resume', { id: d.id });
  VM.act.dlCancel = async d => { if (await VM.confirm({ title: 'Cancelar download?', text: 'O progresso será eliminado.', yes: 'Cancelar download', no: 'Manter', danger: true })) native('dl.cancel', { id: d.id }); };
  VM.act.dlPlay = d => native('dl.play', { id: d.id });
  VM.act.dlOpen = d => native('dl.open', { id: d.id });
  VM.act.dlShare = d => native('dl.share', { id: d.id });
  VM.act.dlWhere = d => { const r = native('dl.where', { id: d.id }); VM.info('Localização do ficheiro', (r && r.location) || 'Desconhecida'); };
  VM.act.dlDelete = async d => { if (await VM.confirm({ title: 'Eliminar ficheiro?', text: 'O ficheiro será removido do dispositivo.', yes: 'Eliminar', danger: true })) native('dl.delete', { id: d.id }); };
})();
