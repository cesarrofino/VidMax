package app.vidmax

import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Analisa links e páginas para descobrir ficheiros que o servidor disponibiliza realmente para
 * descarregamento. Nunca inventa qualidades: tudo vem de cabeçalhos HTTP, listas HLS ou da própria página.
 * Plataformas que não permitem descarregamento fora das suas funcionalidades oficiais são apenas
 * reconhecidas (sem tentativa de extração nem de contorno de proteções).
 */
object Analyzer {
    const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
    private val probeClient: OkHttpClient by lazy {
        client.newBuilder().callTimeout(20, TimeUnit.SECONDS).build()
    }

    // ---------- Plataformas ----------
    class Platform(val id: String, val name: String, val restricted: Boolean)

    fun hostOf(url: String): String = url.toHttpUrlOrNull()?.host ?: ""

    fun platformOf(host: String): Platform? {
        val h = host.lowercase(Locale.ROOT)
        fun m(vararg d: String) = d.any { h == it || h.endsWith(".$it") }
        return when {
            m("youtube.com", "youtu.be", "youtube-nocookie.com") -> Platform("youtube", "YouTube", true)
            m("tiktok.com") -> Platform("tiktok", "TikTok", true)
            m("instagram.com") -> Platform("instagram", "Instagram", true)
            m("facebook.com", "fb.watch", "fb.com") -> Platform("facebook", "Facebook", true)
            m("x.com", "twitter.com", "t.co") -> Platform("x", "X", true)
            m("vimeo.com") -> Platform("vimeo", "Vimeo", false)
            m("dailymotion.com", "dai.ly") -> Platform("dailymotion", "Dailymotion", false)
            else -> null
        }
    }

    // ---------- URLs ----------
    private val urlRegex = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE)
    private val domainRegex = Regex("^[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+(:\\d+)?(/\\S*)?$")
    private val ipRegex = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/\\S*)?$")

    fun extractUrl(text: String): String? =
        urlRegex.find(text)?.value?.trimEnd('.', ',', ')', ';', '!', '?')

    fun normalize(input: String): String? {
        val t = input.trim()
        if (t.isEmpty() || t.length > 4000) return null
        val c = extractUrl(t)
            ?: if (!t.contains(' ') && ipRegex.matches(t)) "http://$t"
            else if (!t.contains(' ') && domainRegex.matches(t)) "https://$t"
            else return null
        val u = c.toHttpUrlOrNull() ?: return null
        return u.toString()
    }

    fun err(msg: String): JSONObject = JSONObject().put("ok", false).put("message", msg).put("options", JSONArray())

    fun restricted(p: Platform, url: String): JSONObject {
        val msg = when (p.id) {
            "youtube" -> "O YouTube só permite descarregar através das suas funcionalidades oficiais (por exemplo, o download offline do YouTube Premium). O VidMax respeita os termos da plataforma e não extrai vídeos do YouTube."
            else -> "${p.name} não disponibiliza descarregamento direto fora das suas funcionalidades oficiais. O VidMax respeita os termos da plataforma e os direitos de autor. Use a opção de guardar/descarregar da própria aplicação, quando o autor a permitir."
        }
        return JSONObject().put("ok", true).put("restricted", true).put("url", url)
            .put("platform", p.name).put("title", "").put("thumb", "").put("message", msg).put("options", JSONArray())
    }

    // ---------- HTTP ----------
    fun req(url: String, referer: String?, range: String? = null): Request.Builder {
        val b = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Accept", "*/*")
            .header("Accept-Language", "pt-PT,pt;q=0.9,en;q=0.8")
        if (!referer.isNullOrEmpty()) b.header("Referer", referer)
        try {
            val c = CookieManager.getInstance().getCookie(url)
            if (!c.isNullOrEmpty()) b.header("Cookie", c)
        } catch (ignored: Throwable) {}
        if (range != null) b.header("Range", range)
        return b
    }

    class Probe(val url: String, val mime: String, val length: Long, val ranges: Boolean, val fileName: String)

    private fun fileNameFrom(r: Response): String {
        val cd = r.header("Content-Disposition") ?: ""
        Regex("filename\\*\\s*=\\s*[^']*''([^;]+)", RegexOption.IGNORE_CASE).find(cd)?.let {
            try { return URLDecoder.decode(it.groupValues[1].trim('"'), "UTF-8") } catch (ignored: Exception) {}
        }
        Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)?.let {
            return it.groupValues[1].trim()
        }
        val seg = r.request.url.pathSegments.lastOrNull { it.isNotEmpty() } ?: ""
        return try { URLDecoder.decode(seg, "UTF-8") } catch (ignored: Exception) { seg }
    }

    fun probe(url: String, referer: String?): Probe? {
        var resp: Response? = null
        try {
            resp = probeClient.newCall(req(url, referer).head().build()).execute()
        } catch (ignored: Exception) {}
        if (resp == null || !resp.isSuccessful) {
            resp?.close()
            resp = try {
                probeClient.newCall(req(url, referer, "bytes=0-0").get().build()).execute()
            } catch (ignored: Exception) { return null }
        }
        val r = resp ?: return null
        r.use {
            if (!it.isSuccessful) return null
            val mime = (it.header("Content-Type") ?: "").substringBefore(';').trim().lowercase(Locale.ROOT)
            var len = it.header("Content-Length")?.toLongOrNull() ?: -1L
            if (it.code == 206) {
                it.header("Content-Range")?.substringAfter('/', "")?.toLongOrNull()?.let { t -> len = t }
            }
            val ranges = it.code == 206 || it.header("Accept-Ranges")?.contains("bytes", true) == true
            return Probe(it.request.url.toString(), mime, len, ranges, fileNameFrom(it))
        }
    }

    fun fetchText(url: String, referer: String?, limit: Int = 3_000_000): String? = try {
        probeClient.newBuilder().callTimeout(30, TimeUnit.SECONDS).build()
            .newCall(req(url, referer).get().build()).execute().use { r ->
                if (!r.isSuccessful) null
                else r.body?.byteStream()?.let { String(readLimited(it, limit), Charsets.UTF_8) }
            }
    } catch (ignored: Exception) { null }

    private fun readLimited(i: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        while (out.size() < limit) {
            val n = i.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun isHlsMime(m: String) = m == "application/vnd.apple.mpegurl" || m == "application/x-mpegurl" ||
        m == "audio/mpegurl" || m == "audio/x-mpegurl"

    private fun isHtmlMime(m: String) = m == "text/html" || m == "application/xhtml+xml"

    // ---------- Opções ----------
    class Cand(val url: String, val quality: String = "")

    private fun option(
        p: Probe, title: String, thumb: String, quality: String, referer: String, source: String
    ): JSONObject {
        var ext = U.extOf(p.fileName)
        if (ext.isEmpty() || ext.length > 5) ext = U.extFromMime(p.mime)
        if (ext.isEmpty()) ext = U.extOf(p.url)
        if (ext.isEmpty()) ext = "bin"
        val kind = U.kindOf(p.mime, ext)
        val base = if (title.isNotEmpty()) title else p.fileName.substringBeforeLast('.', p.fileName)
        var name = U.safeName(base)
        if (quality.isNotEmpty()) name += " (${quality})"
        return JSONObject()
            .put("url", p.url).put("referer", referer).put("name", "$name.$ext").put("ext", ext)
            .put("mime", U.normalizeMime(kind, ext, p.mime)).put("kind", kind).put("quality", quality)
            .put("size", p.length).put("sizeEst", false).put("hls", false).put("segTotal", 0)
            .put("ranges", p.ranges).put("source", source).put("thumb", thumb).put("note", "")
    }

    // ---------- HLS ----------
    class HlsInfo(
        val duration: Double, val segments: List<String>, val encrypted: Boolean, val live: Boolean, val initUrl: String?
    )

    fun parseMediaPlaylist(base: String, text: String): HlsInfo {
        val baseUrl = base.toHttpUrlOrNull()
        var dur = 0.0
        var enc = false
        var endList = false
        var init: String? = null
        val segs = ArrayList<String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#")) {
                when {
                    line.startsWith("#EXTINF:") -> dur += line.substringAfter(':').substringBefore(',').toDoubleOrNull() ?: 0.0
                    line.startsWith("#EXT-X-KEY:") -> if (!line.contains("METHOD=NONE")) enc = true
                    line.startsWith("#EXT-X-SESSION-KEY:") -> if (!line.contains("METHOD=NONE")) enc = true
                    line.startsWith("#EXT-X-ENDLIST") -> endList = true
                    line.startsWith("#EXT-X-MAP:") -> {
                        val u = hlsAttrs(line.substringAfter(':'))["URI"]
                        if (u != null) init = baseUrl?.resolve(u)?.toString()
                    }
                }
            } else {
                baseUrl?.resolve(line)?.toString()?.let { segs.add(it) }
            }
        }
        return HlsInfo(dur, segs, enc, !endList, init)
    }

    private fun hlsAttrs(s: String): Map<String, String> {
        val m = HashMap<String, String>()
        Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)").findAll(s).forEach {
            m[it.groupValues[1]] = it.groupValues[2].trim('"')
        }
        return m
    }

    private class Variant(val url: String, val bandwidth: Long, val height: Int, val audioGroup: String?)

    /** Devolve (opções, urls das variantes, mensagem de erro). */
    private fun hlsOptions(
        text: String, playlistUrl: String, referer: String, title: String, thumb: String, source: String
    ): Triple<List<JSONObject>, Set<String>, String?> {
        val baseUrl = playlistUrl.toHttpUrlOrNull() ?: return Triple(emptyList(), emptySet(), "Lista HLS inválida")
        val out = ArrayList<JSONObject>()
        val covered = HashSet<String>()
        var problem: String? = null

        fun make(url: String, bandwidth: Long, height: Int, silent: Boolean): JSONObject? {
            val t = fetchText(url, referer) ?: return null
            val info = parseMediaPlaylist(url, t)
            if (info.encrypted) { problem = "Este stream está protegido por encriptação e não pode ser descarregado."; return null }
            if (info.live) { problem = "Transmissões em direto não são suportadas."; return null }
            if (info.segments.isEmpty()) return null
            val fmp4 = info.initUrl != null
            val ext = if (fmp4) "mp4" else "ts"
            val q = U.qualityLabel(height)
            var name = U.safeName(if (title.isNotEmpty()) title else "video")
            if (q.isNotEmpty()) name += " ($q)"
            val est = if (bandwidth > 0 && info.duration > 0) (bandwidth * info.duration / 8).toLong() else -1L
            return JSONObject()
                .put("url", url).put("referer", referer).put("name", "$name.$ext").put("ext", ext)
                .put("mime", if (fmp4) "video/mp4" else "video/mp2t").put("kind", "video").put("quality", q)
                .put("size", est).put("sizeEst", true).put("hls", true).put("segTotal", info.segments.size)
                .put("ranges", false).put("source", source).put("thumb", thumb)
                .put("note", if (silent) "sem áudio incorporado" else "")
        }

        if (text.contains("#EXT-X-STREAM-INF")) {
            val audioWithUri = HashSet<String>()
            val variants = ArrayList<Variant>()
            var pending: Map<String, String>? = null
            for (raw in text.lineSequence()) {
                val line = raw.trim()
                if (line.startsWith("#EXT-X-MEDIA:")) {
                    val a = hlsAttrs(line.substringAfter(':'))
                    if (a["TYPE"] == "AUDIO" && a["URI"] != null) a["GROUP-ID"]?.let { audioWithUri.add(it) }
                } else if (line.startsWith("#EXT-X-STREAM-INF:")) {
                    pending = hlsAttrs(line.substringAfter(':'))
                } else if (line.isNotEmpty() && !line.startsWith("#") && pending != null) {
                    val a = pending!!
                    pending = null
                    val u = baseUrl.resolve(line)?.toString() ?: continue
                    val h = a["RESOLUTION"]?.substringAfter('x', "")?.toIntOrNull() ?: 0
                    variants.add(Variant(u, a["BANDWIDTH"]?.toLongOrNull() ?: 0L, h, a["AUDIO"]))
                }
            }
            variants.forEach { covered.add(it.url) }
            val best = variants.groupBy { it.height }.map { e -> e.value.maxByOrNull { it.bandwidth }!! }
                .sortedByDescending { it.height }.take(8)
            for (v in best) {
                val silent = v.audioGroup != null && audioWithUri.contains(v.audioGroup)
                make(v.url, v.bandwidth, v.height, silent)?.let { out.add(it) }
            }
        } else {
            make(playlistUrl, 0, 0, false)?.let { out.add(it) }
        }
        return Triple(out, covered, if (out.isEmpty()) problem else null)
    }

    // ---------- Páginas HTML ----------
    private class PageInfo(val title: String, val thumb: String, val cands: List<Cand>)

    private fun attr(tag: String, name: String): String? {
        val m = Regex("\\b" + Regex.escape(name) + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE).find(tag)
            ?: return null
        val v = if (m.groupValues[2].isNotEmpty()) m.groupValues[2] else m.groupValues[3]
        return v.replace("&amp;", "&").trim()
    }

    private fun qualityHint(s: String?): String {
        if (s.isNullOrBlank()) return ""
        val m = Regex("(\\d{3,4})\\s*p?", RegexOption.IGNORE_CASE).find(s) ?: return ""
        val n = m.groupValues[1].toIntOrNull() ?: return ""
        return if (n in 144..4320) U.qualityLabel(n) else ""
    }

    private fun parsePage(url: String, html: String): PageInfo {
        val base = url.toHttpUrlOrNull()
        var title = ""
        var thumb = ""
        val cands = ArrayList<Cand>()
        fun add(u: String?, q: String = "") {
            if (u.isNullOrBlank() || u.startsWith("blob:") || u.startsWith("data:")) return
            val abs = base?.resolve(u.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&"))?.toString() ?: return
            if (!abs.startsWith("http")) return
            cands.add(Cand(abs, q))
        }
        Regex("<meta\\s+[^>]*>", RegexOption.IGNORE_CASE).findAll(html).forEach { m ->
            val tag = m.value
            val key = (attr(tag, "property") ?: attr(tag, "name") ?: "").lowercase(Locale.ROOT)
            val content = attr(tag, "content") ?: return@forEach
            when (key) {
                "og:title" -> if (title.isEmpty()) title = content
                "og:image", "twitter:image" -> if (thumb.isEmpty()) thumb = base?.resolve(content)?.toString() ?: ""
                "og:video", "og:video:url", "og:video:secure_url", "og:audio", "og:audio:url",
                "og:audio:secure_url", "twitter:player:stream" -> add(content)
            }
        }
        if (title.isEmpty()) {
            Regex("<title[^>]*>([^<]*)</title>", RegexOption.IGNORE_CASE).find(html)?.let {
                title = it.groupValues[1].replace("&amp;", "&").trim()
            }
        }
        Regex("<(video|audio|source)\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html).forEach { m ->
            val tag = m.value
            val q = qualityHint(attr(tag, "label") ?: attr(tag, "res") ?: attr(tag, "size") ?: attr(tag, "data-res") ?: attr(tag, "title"))
            add(attr(tag, "src"), q)
            if (thumb.isEmpty()) attr(tag, "poster")?.let { thumb = base?.resolve(it)?.toString() ?: "" }
        }
        Regex("https?:(?:\\\\?/){2}[^\"'\\s<>\\\\]+?\\.(?:mp4|webm|m3u8|mp3|m4a)(?:\\?[^\"'\\s<>\\\\]*)?", RegexOption.IGNORE_CASE)
            .findAll(html).take(30).forEach { add(it.value) }
        return PageInfo(title, thumb, cands)
    }

    // ---------- API principal ----------
    suspend fun analyze(raw: String): JSONObject = withContext(Dispatchers.IO) {
        val url = normalize(raw) ?: return@withContext err("Link inválido. Cole um endereço http(s) completo.")
        val plat = platformOf(hostOf(url))
        if (plat != null && plat.restricted) return@withContext restricted(plat, url)
        val source = plat?.name ?: hostOf(url)
        val p = probe(url, null) ?: return@withContext err("Não foi possível ligar ao servidor. Verifique a ligação e o endereço.")
        when {
            isHlsMime(p.mime) || U.extOf(p.url) == "m3u8" -> {
                val text = fetchText(p.url, url) ?: return@withContext err("Não foi possível ler a lista de reprodução.")
                val (opts, _, problem) = hlsOptions(text, p.url, url, "", "", source)
                result(url, source, "", "", opts, problem ?: "Não foram encontrados streams descarregáveis.")
            }
            isHtmlMime(p.mime) -> {
                val html = fetchText(p.url, null) ?: return@withContext err("Não foi possível ler a página.")
                val info = parsePage(p.url, html)
                val res = analyzeCandidates(info.cands, p.url, info.title, info.thumb)
                if (res.optJSONArray("options")?.length() == 0) {
                    res.put("message", "Esta página não expõe nenhum ficheiro de vídeo ou áudio descarregável. Se o conteúdo for reproduzido dentro da página, abra-a no navegador do VidMax e use o botão de download.")
                }
                res.put("url", url)
            }
            else -> {
                val o = option(p, "", "", "", "", source)
                result(url, source, "", "", listOf(o), "")
            }
        }
    }

    private fun result(url: String, platform: String, title: String, thumb: String, opts: List<JSONObject>, msg: String): JSONObject {
        val arr = JSONArray()
        opts.forEach { arr.put(it) }
        return JSONObject().put("ok", true).put("restricted", false).put("url", url).put("platform", platform)
            .put("title", title).put("thumb", thumb).put("options", arr).put("message", if (opts.isEmpty()) msg else "")
    }

    /** Sonda os candidatos (HEAD/Range) e devolve apenas os que o servidor confirma como multimédia/ficheiro. */
    suspend fun analyzeCandidates(cands: List<Cand>, pageUrl: String, title: String, thumb: String): JSONObject {
        val source = platformOf(hostOf(pageUrl))?.name ?: hostOf(pageUrl)
        val unique = LinkedHashMap<String, Cand>()
        for (c in cands) {
            val key = c.url.substringBefore('#')
            if (key.startsWith("http") && !unique.containsKey(key)) unique[key] = c
            if (unique.size >= 24) break
        }
        val probed: List<Pair<Cand, Probe?>> = coroutineScope {
            unique.values.map { c -> async(Dispatchers.IO) { c to probe(c.url, pageUrl) } }.awaitAll()
        }
        val options = ArrayList<JSONObject>()
        val covered = HashSet<String>()
        val seen = HashSet<String>()
        var problem: String? = null
        val hlsItems = ArrayList<Pair<Cand, Probe>>()
        for ((c, p) in probed) {
            if (p == null) continue
            val isHls = isHlsMime(p.mime) || U.extOf(p.url) == "m3u8"
            when {
                isHls -> hlsItems.add(c to p)
                p.mime.startsWith("video/") || p.mime.startsWith("audio/") ||
                    (p.mime == "application/octet-stream" && U.isMediaUrl(p.url)) -> {
                    if (seen.add(p.url)) options.add(option(p, title, thumb, c.quality, pageUrl, source))
                }
            }
        }
        // Listas mestras primeiro, para ignorar variantes duplicadas.
        val texts = withContext(Dispatchers.IO) {
            hlsItems.map { (_, p) -> async { p to fetchText(p.url, pageUrl) } }.awaitAll()
        }
        for ((p, text) in texts) {
            if (text == null || !text.contains("#EXT-X-STREAM-INF")) continue
            val (opts, cov, prob) = hlsOptions(text, p.url, pageUrl, title, thumb, source)
            covered.addAll(cov)
            if (prob != null) problem = prob
            opts.forEach { if (seen.add(it.getString("url"))) options.add(it) }
        }
        for ((p, text) in texts) {
            if (text == null || text.contains("#EXT-X-STREAM-INF")) continue
            if (covered.contains(p.url) || !seen.add(p.url)) continue
            val (opts, _, prob) = hlsOptions(text, p.url, pageUrl, title, thumb, source)
            if (prob != null) problem = prob
            opts.forEach { options.add(it) }
        }
        options.sortWith(compareBy<JSONObject>({ if (it.getString("kind") == "video") 0 else if (it.getString("kind") == "audio") 1 else 2 },
            { -(Regex("\\d+").find(it.getString("quality"))?.value?.toIntOrNull() ?: 0) }))
        val msg = problem ?: "Nenhum conteúdo descarregável foi encontrado nesta página. Reproduza o vídeo e toque novamente, ou abra uma página que ofereça o ficheiro diretamente."
        return result(pageUrl, source, title, thumb, options, msg)
    }
}
