package app.vidmax

import java.util.Locale

object U {
    const val ASSET_ORIGIN = "https://appassets.androidplatform.net"

    val videoExt = setOf("mp4", "webm", "mkv", "mov", "m4v", "avi", "3gp", "ts", "flv", "mpg", "mpeg", "ogv")
    val audioExt = setOf("mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac", "weba", "amr")

    fun extOf(path: String): String {
        val last = path.substringBefore('#').substringBefore('?').substringAfterLast('/')
        val i = last.lastIndexOf('.')
        return if (i in 0 until last.length - 1) last.substring(i + 1).lowercase(Locale.ROOT).take(6) else ""
    }

    /** Extensões que valem a pena detetar no tráfego do navegador (sem .ts para não listar segmentos HLS). */
    fun isSniffable(url: String): Boolean {
        if (!url.startsWith("http")) return false
        val e = extOf(url)
        return (e in videoExt && e != "ts") || e in audioExt || e == "m3u8"
    }

    fun isMediaUrl(url: String): Boolean {
        val e = extOf(url)
        return e in videoExt || e in audioExt || e == "m3u8"
    }

    fun mimeFromExt(e: String): String = when (e.lowercase(Locale.ROOT)) {
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "avi" -> "video/x-msvideo"
        "3gp" -> "video/3gpp"
        "ts" -> "video/mp2t"
        "flv" -> "video/x-flv"
        "mpg", "mpeg" -> "video/mpeg"
        "ogv" -> "video/ogg"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "aac" -> "audio/aac"
        "ogg", "oga", "opus" -> "audio/ogg"
        "wav" -> "audio/wav"
        "flac" -> "audio/flac"
        "weba" -> "audio/webm"
        "amr" -> "audio/amr"
        "pdf" -> "application/pdf"
        "zip" -> "application/zip"
        "apk" -> "application/vnd.android.package-archive"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "txt" -> "text/plain"
        else -> "application/octet-stream"
    }

    fun extFromMime(mime: String): String = when (mime.substringBefore(';').trim().lowercase(Locale.ROOT)) {
        "video/mp4" -> "mp4"
        "video/webm" -> "webm"
        "video/x-matroska" -> "mkv"
        "video/quicktime" -> "mov"
        "video/x-msvideo" -> "avi"
        "video/3gpp" -> "3gp"
        "video/mp2t" -> "ts"
        "video/x-flv" -> "flv"
        "video/mpeg" -> "mpg"
        "video/ogg" -> "ogv"
        "audio/mpeg", "audio/mp3" -> "mp3"
        "audio/mp4", "audio/x-m4a" -> "m4a"
        "audio/aac" -> "aac"
        "audio/ogg" -> "ogg"
        "audio/wav", "audio/x-wav" -> "wav"
        "audio/flac" -> "flac"
        "audio/webm" -> "weba"
        "application/pdf" -> "pdf"
        "application/zip" -> "zip"
        "application/vnd.android.package-archive" -> "apk"
        "image/jpeg" -> "jpg"
        "image/png" -> "png"
        "image/gif" -> "gif"
        "image/webp" -> "webp"
        "text/plain" -> "txt"
        else -> ""
    }

    fun kindOf(mime: String, ext: String): String = when {
        mime.startsWith("video/") -> "video"
        mime.startsWith("audio/") -> "audio"
        ext in videoExt -> "video"
        ext in audioExt -> "audio"
        else -> "file"
    }

    /** Garante coerência entre o tipo (vídeo/áudio/ficheiro) e o MIME, exigida pelo MediaStore. */
    fun normalizeMime(kind: String, ext: String, mime: String): String {
        val m = mime.substringBefore(';').trim().lowercase(Locale.ROOT)
        return when (kind) {
            "video" -> if (m.startsWith("video/")) m else mimeFromExt(ext).let { if (it.startsWith("video/")) it else "video/mp4" }
            "audio" -> if (m.startsWith("audio/")) m else mimeFromExt(ext).let { if (it.startsWith("audio/")) it else "audio/mpeg" }
            else -> if (m.isNotEmpty() && m != "application/octet-stream") m else mimeFromExt(ext)
        }
    }

    fun safeName(s: String, fallback: String = "download"): String {
        var n = s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), " ").replace(Regex("\\s+"), " ").trim().trim('.')
        if (n.length > 120) n = n.substring(0, 120).trim()
        return if (n.isEmpty()) fallback else n
    }

    fun qualityLabel(height: Int): String = when {
        height <= 0 -> ""
        height >= 2160 -> "4K (${height}p)"
        height >= 1440 -> "2K (${height}p)"
        else -> "${height}p"
    }
}
