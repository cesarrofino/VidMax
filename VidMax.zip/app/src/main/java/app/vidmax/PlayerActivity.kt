package app.vidmax

import android.content.ComponentName
import android.content.Context
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import java.io.File

/** Reprodutor integrado (vídeo e áudio). A reprodução vive no PlaybackService (segundo plano + notificação). */
@UnstableApi
class PlayerActivity : AppCompatActivity() {
    private lateinit var playerView: PlayerView
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var recs: List<DownloadRecord> = emptyList()
    private var index = 0
    private var kind = "video"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        val ids = intent.getStringArrayExtra("ids") ?: emptyArray()
        recs = ids.mapNotNull { Store.find(it) }.filter { it.uri.isNotEmpty() }
        if (recs.isEmpty()) { Toast.makeText(this, "Ficheiro não encontrado", Toast.LENGTH_SHORT).show(); finish(); return }
        index = intent.getIntExtra("index", 0).coerceIn(0, recs.size - 1)
        kind = recs[index].kind

        playerView = findViewById(R.id.playerView)
        val title = findViewById<TextView>(R.id.txtTitle)
        val audioPanel = findViewById<LinearLayout>(R.id.audioPanel)
        title.text = recs[index].title
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        // Volume
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val seek = findViewById<SeekBar>(R.id.seekVolume)
        seek.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        seek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<ImageButton>(R.id.btnVolume).setOnClickListener {
            seek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            seek.visibility = if (seek.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        volumeControlStream = AudioManager.STREAM_MUSIC

        if (kind == "audio") {
            audioPanel.visibility = View.VISIBLE
            val lp = playerView.layoutParams as LinearLayout.LayoutParams
            lp.height = (220 * resources.displayMetrics.density).toInt()
            lp.weight = 0f
            playerView.layoutParams = lp
            playerView.controllerShowTimeoutMs = 0
            playerView.controllerHideOnTouch = false
            playerView.showController()
        } else {
            audioPanel.visibility = View.GONE
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            WindowCompat.setDecorFitsSystemWindows(window, true)
            if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
                c.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        updateAudioInfo(index)
    }

    private fun updateAudioInfo(i: Int) {
        val r = recs.getOrNull(i) ?: return
        findViewById<TextView>(R.id.txtTitle).text = r.title
        findViewById<TextView>(R.id.txtAudioTitle).text = r.title
        findViewById<TextView>(R.id.txtAudioSub).text = r.source
        val img = findViewById<ImageView>(R.id.imgCover)
        val f = if (r.thumb.isNotEmpty() && !r.thumb.startsWith("http")) File(Storage.thumbDir(this), r.thumb) else null
        if (f != null && f.exists()) img.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
        else img.setImageResource(R.drawable.ic_music_cover)
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                playerView.player = c
                c.addListener(object : androidx.media3.common.Player.Listener {
                    override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                        val id = item?.mediaId ?: return
                        val i = recs.indexOfFirst { it.id == id }
                        if (i >= 0) updateAudioInfo(i)
                    }
                })
                load(c)
            } catch (e: Exception) {
                Toast.makeText(this, "Não foi possível iniciar o reprodutor", Toast.LENGTH_SHORT).show()
                finish()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun load(c: MediaController) {
        val wanted = recs[index]
        if (c.mediaItemCount == recs.size && c.currentMediaItem?.mediaId == wanted.id) {
            if (Store.autoplay && !c.isPlaying) c.play()
            return
        }
        val items = recs.map { r ->
            val art = if (r.thumb.isNotEmpty() && !r.thumb.startsWith("http")) Uri.fromFile(File(Storage.thumbDir(this), r.thumb)) else null
            MediaItem.Builder().setMediaId(r.id).setUri(Uri.parse(r.uri))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(r.title).setArtist(r.source).setArtworkUri(art).build())
                .build()
        }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        if (Store.autoplay) c.play()
    }

    override fun onStop() {
        if (kind == "video") controller?.pause()
        playerView.player = null
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        future = null
        super.onStop()
    }
}
