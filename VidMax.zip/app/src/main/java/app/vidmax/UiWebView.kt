package app.vidmax

import android.content.Context
import android.graphics.Rect
import android.view.MotionEvent
import android.webkit.WebView

/**
 * WebView da interface do VidMax. Fica transparente por cima do navegador; os toques dentro do
 * "buraco" (área da página web) são devolvidos ao WebView do separador que está por baixo.
 */
class UiWebView(ctx: Context) : WebView(ctx) {
    @Volatile var hole: Rect? = null
    @Volatile var exclude: Rect? = null
    private var passing = false

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val x = ev.x.toInt()
            val y = ev.y.toInt()
            val h = hole
            passing = h != null && h.contains(x, y) && exclude?.contains(x, y) != true
        }
        if (passing) return false
        return super.dispatchTouchEvent(ev)
    }
}
