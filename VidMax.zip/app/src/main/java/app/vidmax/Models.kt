package app.vidmax

import org.json.JSONObject

class DownloadRecord(
    var id: String,
    var url: String,
    var referer: String,
    var fileName: String,
    var ext: String,
    var mime: String,
    var kind: String,
    var quality: String,
    var source: String,
    var hls: Boolean
) {
    @Volatile var status: String = "queued" // queued | downloading | paused | failed | completed | canceled
    @Volatile var total: Long = 0L
    @Volatile var sizeEstimated: Boolean = false
    @Volatile var downloaded: Long = 0L
    @Volatile var segIndex: Int = 0
    @Volatile var segTotal: Int = 0
    @Volatile var error: String = ""
    var created: Long = System.currentTimeMillis()
    @Volatile var completed: Long = 0L
    @Volatile var uri: String = ""
    @Volatile var location: String = ""
    @Volatile var thumb: String = ""
    @Volatile var speed: Long = 0L
    @Volatile var eta: Long = -1L

    val title: String get() = fileName.substringBeforeLast('.', fileName)

    fun pct(): Int {
        if (status == "completed") return 100
        val p = if (hls) {
            if (segTotal > 0) segIndex * 100.0 / segTotal else 0.0
        } else {
            if (total > 0) downloaded * 100.0 / total else 0.0
        }
        return p.toInt().coerceIn(0, 100)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("url", url); put("referer", referer); put("fileName", fileName)
        put("ext", ext); put("mime", mime); put("kind", kind); put("quality", quality)
        put("source", source); put("hls", hls); put("status", status); put("total", total)
        put("sizeEst", sizeEstimated); put("downloaded", downloaded); put("segIndex", segIndex)
        put("segTotal", segTotal); put("error", error); put("created", created)
        put("completed", completed); put("uri", uri); put("location", location); put("thumb", thumb)
    }

    fun toUi(): JSONObject = JSONObject().apply {
        put("id", id); put("title", title); put("fileName", fileName); put("ext", ext)
        put("kind", kind); put("quality", quality); put("source", source); put("hls", hls)
        put("status", status); put("total", total); put("sizeEst", sizeEstimated)
        put("downloaded", downloaded); put("pct", pct()); put("speed", speed); put("eta", eta)
        put("error", error); put("created", created); put("completed", completed)
        put("location", location)
        val t = thumb
        put("thumb", when {
            t.isEmpty() -> ""
            t.startsWith("http") -> t
            else -> "${U.ASSET_ORIGIN}/thumbs/$t"
        })
    }

    companion object {
        fun fromJson(o: JSONObject): DownloadRecord {
            val r = DownloadRecord(
                o.getString("id"), o.getString("url"), o.optString("referer"), o.optString("fileName", "download"),
                o.optString("ext"), o.optString("mime"), o.optString("kind", "file"), o.optString("quality"),
                o.optString("source"), o.optBoolean("hls")
            )
            r.status = o.optString("status", "queued")
            r.total = o.optLong("total"); r.sizeEstimated = o.optBoolean("sizeEst")
            r.downloaded = o.optLong("downloaded"); r.segIndex = o.optInt("segIndex")
            r.segTotal = o.optInt("segTotal"); r.error = o.optString("error")
            r.created = o.optLong("created", System.currentTimeMillis()); r.completed = o.optLong("completed")
            r.uri = o.optString("uri"); r.location = o.optString("location"); r.thumb = o.optString("thumb")
            return r
        }
    }
}
