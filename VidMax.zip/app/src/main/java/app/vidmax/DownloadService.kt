package app.vidmax

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Serviço em primeiro plano que mantém os downloads ativos com a aplicação em segundo plano. */
class DownloadService : Service() {
    companion object {
        const val ACTION_PUMP = "app.vidmax.PUMP"
        const val ACTION_PAUSE = "app.vidmax.PAUSE"
        const val ACTION_CANCEL = "app.vidmax.CANCEL"
        const val ACTION_RESUME = "app.vidmax.RESUME"
        const val EXTRA_ID = "id"

        fun kick(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java).setAction(ACTION_PUMP))
            } catch (ignored: Exception) {
                Downloads.pump() // sem serviço (ex.: restrições em segundo plano): corre enquanto o processo viver
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Downloads.init(this)
        Downloads.serviceRunning = true
        Downloads.idleCallback = { stopIfIdle() }
    }

    private fun stopIfIdle() {
        if (Downloads.isIdle()) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Downloads.summaryNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(Downloads.NID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(Downloads.NID_SERVICE, n)
        }
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_PAUSE -> id?.let { Downloads.pause(it) }
            ACTION_CANCEL -> id?.let { Downloads.cancel(it) }
            ACTION_RESUME -> id?.let { Downloads.resume(it, false) }
        }
        Downloads.pump()
        stopIfIdle()
        return START_STICKY
    }

    override fun onDestroy() {
        Downloads.serviceRunning = false
        Downloads.idleCallback = null
        super.onDestroy()
    }
}
