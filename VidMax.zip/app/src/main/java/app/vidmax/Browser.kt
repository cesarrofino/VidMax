package app.vidmax

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AlertDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLEncoder
import java.util.Collections

class BrowserTab(val id: Int, val web: WebView, val priv: Boolean) {
    @Volatile var title = ""
    @Volatile var url = ""
    @Volatile var progress = 0
    @Volatile var loading = false
    val sniffed: MutableSet<String> = Collections.synchronizedSet(LinkedHashSet<String>())
}

/** Gestor de separadores: cada separador é um WebView nativo SEM qualquer interface JavaScript exposta. */
class Browser(private val act: MainActivity, private val host: FrameLayout) {
    private val tabs = ArrayList<BrowserTab>()
    private var active: BrowserTab? = null
    private var nextId = 1
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var pending = false
    @Volatile var cachedState: String = "{}"

    companion object {
        const val ERR_TITLE = "Sem ligação"
        private const val SCAN_JS = """(function(){var out=[],seen={};
function add(u,t,q,h){if(!u||u.indexOf('blob:')==0||u.indexOf('data:')==0)return;try{u=new URL(u,document.baseURI).href}catch(e){return}
if(seen[u])return;seen[u]=1;out.push({u:u,t:t||'',q:q||'',h:h||0});}
document.querySelectorAll('video,audio').forEach(function(m){
add(m.currentSrc||m.src,m.tagName,'',m.videoHeight||0);
m.querySelectorAll('source').forEach(function(s){add(s.src,s.type,'',0)});});
document.querySelectorAll('source[src]').forEach(function(s){add(s.src,s.type,'',0)});
var og=document.querySelector('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[property="og:audio"]');
if(og)add(og.content,'og','',0);
var th=(document.querySelector('video[poster]')||{}).poster||(document.querySelector('meta[property="og:image"]')||{}).content||'';
return JSON.stringify({title:document.title,thumb:th,items:out});})()"""
    }

    // ---------- Criação ----------
    private fun createWebView(priv: Boolean): WebView {
        val w = WebView(act)
        w.setBackgroundColor(Color.WHITE)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (priv) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, !priv)
        return w
    }

    fun newTab(url: String?, priv: Boolean): BrowserTab {
        if (tabs.size >= 16) { act.toast("Limite de 16 separadores atingido"); return active ?: tabs.last() }
        val wv = createWebView(priv)
        val tab = BrowserTab(nextId++, wv, priv)
        wv.webViewClient = client(tab)
        wv.webChromeClient = chrome(tab)
        wv.setDownloadListener { u, _, cd, mime, len -> act.onWebDownload(u, cd, mime, len, tab.url) }
        wv.setOnLongClickListener { onLongPress(tab) }
        host.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        tabs.add(tab)
        select(tab)
        if (!url.isNullOrEmpty()) wv.loadUrl(url)
        notifyChanged()
        return tab
    }

    private fun select(tab: BrowserTab) {
        active?.let { it.web.visibility = View.GONE; it.web.onPause() }
        active = tab
        tab.web.visibility = View.VISIBLE
        tab.web.onResume()
        tab.web.requestFocus()
    }

    fun ensureTab() { if (tabs.isEmpty()) newTab(null, false) }

    fun switchTo(id: Int) { tabs.firstOrNull { it.id == id }?.let { select(it); notifyChanged() } }

    fun closeTab(id: Int) {
        val t = tabs.firstOrNull { it.id == id } ?: return
        val idx = tabs.indexOf(t)
        tabs.remove(t)
        host.removeView(t.web)
        if (t.priv) { t.web.clearCache(true); t.web.clearHistory(); t.web.clearFormData() }
        t.web.destroy()
        if (active === t) {
            active = null
            if (tabs.isEmpty()) newTab(null, false) else select(tabs[idx.coerceAtMost(tabs.size - 1)])
        }
        notifyChanged()
    }

    fun closeAll() { while (tabs.isNotEmpty()) { val t = tabs.removeAt(0); host.removeView(t.web); t.web.destroy() }; active = null; newTab(null, false) }

    fun setVisible(v: Boolean) {
        host.visibility = if (v) View.VISIBLE else View.GONE
        if (v) active?.web?.onResume() else active?.web?.onPause()
    }

    fun destroy() { tabs.forEach { try { it.web.destroy() } catch (ignored: Exception) {} }; tabs.clear() }
    fun onPause() { active?.web?.onPause() }
    fun onResume() { if (host.visibility == View.VISIBLE) active?.web?.onResume() }

    // ---------- Navegação ----------
    private fun searchUrl(q: String): String {
        val e = URLEncoder.encode(q, "UTF-8")
        return when (Store.searchEngine) {
            "google" -> "https://www.google.com/search?q=$e"
            "bing" -> "https://www.bing.com/search?q=$e"
            else -> "https://duckduckgo.com/?q=$e"
        }
    }

    fun resolveInput(text: String): String {
        val t = text.trim()
        if (!t.contains(' ')) Analyzer.normalize(t)?.let { return it }
        return searchUrl(t)
    }

    fun go(text: String) {
        if (text.isBlank()) return
        val tab = active ?: newTab(null, false)
        tab.web.loadUrl(resolveInput(text))
    }

    fun back() { active?.web?.let { if (it.canGoBack()) it.goBack() } }
    fun forward() { active?.web?.let { if (it.canGoForward()) it.goForward() } }
    fun reload() { active?.let { if (it.loading) it.web.stopLoading() else it.web.reload() } }
    fun home() { active?.let { it.web.loadUrl("about:blank"); it.web.clearHistory(); it.url = ""; it.title = ""; it.sniffed.clear(); notifyChanged() } }
    fun canGoBack(): Boolean = active?.web?.canGoBack() == true
    fun currentUrl(): String = active?.url ?: ""
    fun currentTitle(): String = active?.title ?: ""

    // ---------- Estado ----------
    fun stateJson(): JSONObject {
        val o = JSONObject()
        val arr = JSONArray()
        for (t in tabs) {
            arr.put(JSONObject().put("id", t.id).put("title", t.title).put("url", t.url)
                .put("loading", t.loading).put("progress", t.progress).put("priv", t.priv))
        }
        val a = active
        o.put("tabs", arr).put("active", a?.id ?: 0)
        o.put("canBack", a?.web?.canGoBack() == true).put("canForward", a?.web?.canGoForward() == true)
        o.put("media", a?.sniffed?.size ?: 0)
        o.put("blank", a == null || a.url.isEmpty())
        o.put("bookmarked", a != null && a.url.isNotEmpty() && Store.isBookmarked(a.url))
        return o
    }

    fun notifyChanged() {
        val o = stateJson()
        cachedState = o.toString()
        act.emit("browser", cachedState)
    }

    private fun notifyChangedSoon() {
        if (pending) return
        pending = true
        main.postDelayed({ pending = false; notifyChanged() }, 120)
    }

    // ---------- Clientes ----------
    private fun client(tab: BrowserTab) = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
            val u = r.url
            return when (u.scheme?.lowercase()) {
                "http", "https" -> false
                "mailto", "tel" -> { act.openExternal(u.toString()); true }
                else -> true // bloqueia intent:, file:, javascript: e esquemas desconhecidos
            }
        }

        override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
            val s = r.url.toString()
            if (U.isSniffable(s) && tab.sniffed.size < 60 && tab.sniffed.add(s) && tab === active) notifyChangedSoon()
            return null
        }

        override fun onPageStarted(v: WebView, url: String, favicon: Bitmap?) {
            tab.url = if (url == "about:blank") "" else url
            tab.loading = true
            tab.progress = 5
            tab.sniffed.clear()
            notifyChanged()
        }

        override fun onPageFinished(v: WebView, url: String) {
            tab.loading = false
            tab.progress = 100
            tab.title = v.title ?: url
            if (!tab.priv && tab.url.startsWith("http") && tab.title != ERR_TITLE) Store.addHistory(tab.url, tab.title)
            notifyChanged()
        }

        override fun doUpdateVisitedHistory(v: WebView, url: String, isReload: Boolean) {
            if (url != "about:blank" && !url.startsWith("data:")) tab.url = url
            notifyChangedSoon()
        }

        override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
            if (r.isForMainFrame) {
                val u = r.url.toString()
                v.loadDataWithBaseURL(u, errorHtml(u, e.description?.toString() ?: ""), "text/html", "UTF-8", u)
            }
        }

        override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
            main.post { closeTab(tab.id); act.toast("O separador foi terminado por falta de memória") }
            return true
        }
    }

    private fun errorHtml(url: String, desc: String): String {
        val u = TextUtils.htmlEncode(url)
        val d = TextUtils.htmlEncode(desc)
        return """<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>$ERR_TITLE</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:sans-serif;background:#070B19;color:#fff;text-align:center;padding:24px;box-sizing:border-box}
.c{max-width:360px}h1{font-size:22px;margin:16px 0 8px}p{color:#A8B1CE;font-size:14px;word-break:break-word}
a{display:inline-block;margin-top:18px;padding:12px 24px;border-radius:14px;background:linear-gradient(135deg,#713BFF,#1677FF);color:#fff;text-decoration:none;font-weight:600}
.i{width:72px;height:72px;border-radius:24px;margin:auto;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-size:34px}
@media(prefers-color-scheme:light){body{background:#F5F8FF;color:#14213D}p{color:#71809B}}</style></head>
<body><div class="c"><div class="i">!</div><h1>Não foi possível abrir a página</h1><p>$d</p><p>$u</p><a href="$u">Tentar novamente</a></div></body></html>"""
    }

    private fun chrome(tab: BrowserTab) = object : WebChromeClient() {
        override fun onProgressChanged(v: WebView, p: Int) { tab.progress = p; tab.loading = p < 100; notifyChangedSoon() }
        override fun onReceivedTitle(v: WebView, t: String?) { tab.title = t ?: ""; notifyChangedSoon() }
        override fun onShowCustomView(view: View, cb: CustomViewCallback) { act.showCustomView(view, cb) }
        override fun onHideCustomView() { act.hideCustomView() }
        override fun onPermissionRequest(r: PermissionRequest) { act.onWebPermission(r) }
        override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) { act.onWebGeo(origin, cb) }
        override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<android.net.Uri>>, p: FileChooserParams): Boolean = act.onFileChooser(cb, p)
        override fun onJsAlert(v: WebView, url: String, message: String, r: JsResult): Boolean {
            AlertDialog.Builder(act).setMessage(message).setPositiveButton("OK") { _, _ -> r.confirm() }
                .setOnCancelListener { r.cancel() }.show()
            return true
        }
        override fun onJsConfirm(v: WebView, url: String, message: String, r: JsResult): Boolean {
            AlertDialog.Builder(act).setMessage(message).setPositiveButton("OK") { _, _ -> r.confirm() }
                .setNegativeButton("Cancelar") { _, _ -> r.cancel() }.setOnCancelListener { r.cancel() }.show()
            return true
        }
    }

    private fun onLongPress(tab: BrowserTab): Boolean {
        val hit = tab.web.hitTestResult
        val extra = hit.extra ?: return false
        val t = hit.type
        if (t != WebView.HitTestResult.SRC_ANCHOR_TYPE && t != WebView.HitTestResult.IMAGE_TYPE &&
            t != WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) return false
        if (!extra.startsWith("http")) return false
        val labels = arrayOf("Abrir em novo separador", "Analisar para descarregar", "Copiar link", "Partilhar link")
        AlertDialog.Builder(act).setTitle(extra.take(80)).setItems(labels) { _, i ->
            when (i) {
                0 -> newTab(extra, tab.priv)
                1 -> act.analyzeUrl(extra)
                2 -> act.copyText(extra)
                3 -> act.shareText(extra)
            }
        }.show()
        return true
    }

    // ---------- Deteção de multimédia ----------
    fun scan(rid: String) {
        val t = active
        if (t == null || t.url.isEmpty()) {
            act.emit("options", Analyzer.err("Abra uma página com vídeo ou áudio e toque novamente no botão de download.").put("rid", rid).toString())
            return
        }
        val pageUrl = t.url
        val plat = Analyzer.platformOf(Analyzer.hostOf(pageUrl))
        if (plat != null && plat.restricted) {
            act.emit("options", Analyzer.restricted(plat, pageUrl).put("rid", rid).toString())
            return
        }
        val sniffed = synchronized(t.sniffed) { ArrayList(t.sniffed) }
        t.web.evaluateJavascript(SCAN_JS) { raw ->
            act.scope.launch(Dispatchers.IO) {
                val cands = ArrayList<Analyzer.Cand>()
                var title = t.title
                var thumb = ""
                try {
                    val s = JSONTokener(raw).nextValue() as? String
                    if (s != null) {
                        val o = JSONObject(s)
                        title = o.optString("title", title)
                        thumb = o.optString("thumb", "")
                        val items = o.optJSONArray("items") ?: JSONArray()
                        for (i in 0 until items.length()) {
                            val it = items.getJSONObject(i)
                            cands.add(Analyzer.Cand(it.getString("u"), U.qualityLabel(it.optInt("h"))))
                        }
                    }
                } catch (ignored: Exception) {}
                sniffed.forEach { cands.add(Analyzer.Cand(it)) }
                val res = try {
                    Analyzer.analyzeCandidates(cands, pageUrl, title, thumb)
                } catch (e: Exception) {
                    Analyzer.err("Falha ao analisar a página.")
                }
                act.emit("options", res.put("rid", rid).toString())
            }
        }
    }

    fun clearSiteData() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    fun clearCache() { tabs.firstOrNull()?.web?.clearCache(true) }
}
