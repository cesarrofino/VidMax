package app.vidmax

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/** Persistência local: definições, histórico, favoritos e registo de downloads. Tudo fica no dispositivo. */
object Store {
    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private val lock = Any()
    private val downloads = ArrayList<DownloadRecord>()
    private val history = ArrayList<JSONObject>()
    private val bookmarks = ArrayList<JSONObject>()
    val dlListeners = CopyOnWriteArrayList<() -> Unit>()
    @Volatile private var lastSave = 0L

    fun init(ctx: Context) {
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("vidmax", Context.MODE_PRIVATE)
        synchronized(lock) {
            downloads.clear(); history.clear(); bookmarks.clear()
            val d = readArray("downloads.json")
            for (i in 0 until d.length()) {
                try {
                    val r = DownloadRecord.fromJson(d.getJSONObject(i))
                    if (r.status == "downloading") r.status = "queued" // recuperação após encerramento inesperado
                    downloads.add(r)
                } catch (ignored: Exception) {}
            }
            val h = readArray("history.json")
            for (i in 0 until h.length()) h.optJSONObject(i)?.let { history.add(it) }
            val b = readArray("bookmarks.json")
            for (i in 0 until b.length()) b.optJSONObject(i)?.let { bookmarks.add(it) }
        }
    }

    // ---------- Definições ----------
    var theme: String
        get() = prefs.getString("theme", "auto") ?: "auto"
        set(v) { prefs.edit().putString("theme", v).apply() }
    var maxConcurrent: Int
        get() = prefs.getInt("max", 2).coerceIn(1, 5)
        set(v) { prefs.edit().putInt("max", v.coerceIn(1, 5)).apply() }
    var notifications: Boolean
        get() = prefs.getBoolean("notif", true)
        set(v) { prefs.edit().putBoolean("notif", v).apply() }
    var autoplay: Boolean
        get() = prefs.getBoolean("autoplay", true)
        set(v) { prefs.edit().putBoolean("autoplay", v).apply() }
    var treeUri: String
        get() = prefs.getString("tree", "") ?: ""
        set(v) { prefs.edit().putString("tree", v).apply() }
    var treeName: String
        get() = prefs.getString("treeName", "") ?: ""
        set(v) { prefs.edit().putString("treeName", v).apply() }
    var searchEngine: String
        get() = prefs.getString("search", "duckduckgo") ?: "duckduckgo"
        set(v) { prefs.edit().putString("search", v).apply() }
    var saveHistory: Boolean
        get() = prefs.getBoolean("saveHistory", true)
        set(v) { prefs.edit().putBoolean("saveHistory", v).apply() }

    fun effectiveDark(ctx: Context): Boolean = when (theme) {
        "dark" -> true
        "light" -> false
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun settingsJson(): JSONObject = JSONObject()
        .put("theme", theme).put("maxConcurrent", maxConcurrent).put("notifications", notifications)
        .put("autoplay", autoplay).put("folder", treeName).put("searchEngine", searchEngine)
        .put("saveHistory", saveHistory)

    fun setSetting(k: String, v: Any?) {
        when (k) {
            "theme" -> theme = v.toString().takeIf { it in setOf("auto", "light", "dark") } ?: "auto"
            "maxConcurrent" -> maxConcurrent = (v as? Number)?.toInt() ?: v.toString().toIntOrNull() ?: 2
            "notifications" -> notifications = v as? Boolean ?: (v.toString() == "true")
            "autoplay" -> autoplay = v as? Boolean ?: (v.toString() == "true")
            "searchEngine" -> searchEngine = v.toString().takeIf { it in setOf("duckduckgo", "google", "bing") } ?: "duckduckgo"
            "saveHistory" -> saveHistory = v as? Boolean ?: (v.toString() == "true")
        }
    }

    // ---------- Downloads ----------
    fun snapshot(): List<DownloadRecord> = synchronized(lock) { ArrayList(downloads) }
    fun find(id: String): DownloadRecord? = synchronized(lock) { downloads.firstOrNull { it.id == id } }
    fun addDownload(r: DownloadRecord) { synchronized(lock) { downloads.add(r) }; saveDownloads(true); fireDownloads() }
    fun removeDownload(id: String): DownloadRecord? {
        val r = synchronized(lock) { downloads.firstOrNull { it.id == id }?.also { downloads.remove(it) } }
        saveDownloads(true); fireDownloads()
        return r
    }
    fun listUi(): JSONArray = synchronized(lock) { JSONArray().also { a -> downloads.forEach { a.put(it.toUi()) } } }
    fun fireDownloads() { dlListeners.forEach { try { it() } catch (ignored: Exception) {} } }

    fun saveDownloads(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastSave < 2000) return
        lastSave = now
        val arr = synchronized(lock) { JSONArray().also { a -> downloads.forEach { a.put(it.toJson()) } } }
        writeArray("downloads.json", arr)
    }

    // ---------- Histórico ----------
    fun addHistory(url: String, title: String) {
        if (!saveHistory) return
        synchronized(lock) {
            val now = System.currentTimeMillis()
            if (history.isNotEmpty() && history[0].optString("url") == url) {
                history[0].put("title", title).put("t", now)
            } else {
                history.add(0, JSONObject().put("url", url).put("title", title).put("t", now))
                while (history.size > 1000) history.removeAt(history.size - 1)
            }
            writeArray("history.json", JSONArray(history))
        }
    }
    fun historyList(): JSONArray = synchronized(lock) { JSONArray(history) }
    fun clearHistory() { synchronized(lock) { history.clear(); writeArray("history.json", JSONArray()) } }
    fun removeHistory(url: String, t: Long) {
        synchronized(lock) {
            history.removeAll { it.optString("url") == url && it.optLong("t") == t }
            writeArray("history.json", JSONArray(history))
        }
    }

    // ---------- Favoritos ----------
    fun isBookmarked(url: String): Boolean = synchronized(lock) { bookmarks.any { it.optString("url") == url } }
    fun bookmarksList(): JSONArray = synchronized(lock) { JSONArray(bookmarks) }
    fun toggleBookmark(url: String, title: String): Boolean = synchronized(lock) {
        val ex = bookmarks.firstOrNull { it.optString("url") == url }
        val added: Boolean
        if (ex != null) { bookmarks.remove(ex); added = false }
        else { bookmarks.add(0, JSONObject().put("url", url).put("title", title.ifEmpty { url }).put("t", System.currentTimeMillis())); added = true }
        writeArray("bookmarks.json", JSONArray(bookmarks))
        added
    }
    fun removeBookmark(url: String) {
        synchronized(lock) {
            bookmarks.removeAll { it.optString("url") == url }
            writeArray("bookmarks.json", JSONArray(bookmarks))
        }
    }

    // ---------- Ficheiros ----------
    private fun readArray(name: String): JSONArray = try {
        val f = File(app.filesDir, name)
        if (f.exists()) JSONArray(f.readText()) else JSONArray()
    } catch (ignored: Exception) { JSONArray() }

    private fun writeArray(name: String, arr: JSONArray) {
        try {
            val f = File(app.filesDir, name)
            val tmp = File(app.filesDir, "$name.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (ignored: Exception) {}
    }
}
