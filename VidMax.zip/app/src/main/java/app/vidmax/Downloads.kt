package app.vidmax

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.Call
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.SSLException

class StoppedException : RuntimeException()
class UserError(msg: String) : Exception(msg)
class HttpFailure(val code: Int) : Exception("HTTP $code")

/** Motor de downloads: fila, simultaneidade, pausa/retoma (HTTP Range), HLS, notificações. */
object Downloads {
    const val CH_SERVICE = "vm_service"
    const val CH_PROGRESS = "vm_progress"
    const val CH_DONE = "vm_done"
    const val NID_SERVICE = 4001

    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val calls = ConcurrentHashMap<String, Call>()
    private val lastNotif = ConcurrentHashMap<String, Long>()
    private val main = Handler(Looper.getMainLooper())
    @Volatile var idleCallback: (() -> Unit)? = null
    @Volatile var serviceRunning = false

    private val dlClient by lazy { Analyzer.client.newBuilder().readTimeout(30, java.util.concurrent.TimeUnit.SECONDS).build() }

    fun init(ctx: Context) { app = ctx.applicationContext }

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, ctx.getString(R.string.notif_channel_service), NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, ctx.getString(R.string.notif_channel_progress), NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, ctx.getString(R.string.notif_channel_done), NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun activeCount() = jobs.size
    fun queuedCount() = Store.snapshot().count { it.status == "queued" }
    fun isIdle() = jobs.isEmpty() && queuedCount() == 0

    // ---------- Controlo ----------
    @Synchronized
    fun pump() {
        val max = Store.maxConcurrent
        for (rec in Store.snapshot()) {
            if (jobs.size >= max) break
            if (rec.status == "queued" && !jobs.containsKey(rec.id)) launch(rec)
        }
        Store.fireDownloads()
    }

    private fun launch(rec: DownloadRecord) {
        rec.status = "downloading"; rec.error = ""
        val job = scope.launch(start = CoroutineStart.LAZY) { runTask(rec) }
        jobs[rec.id] = job
        job.start()
    }

    fun enqueued() { DownloadService.kick(app) }

    fun pause(id: String) {
        val r = Store.find(id) ?: return
        if (r.status == "downloading" || r.status == "queued") {
            r.status = "paused"; r.speed = 0
            jobs[id]?.cancel(); calls[id]?.cancel()
            cancelNotif(r)
            Store.saveDownloads(true); Store.fireDownloads()
            main.post { idleCallback?.invoke() }
        }
    }

    fun resume(id: String, kick: Boolean = true) {
        val r = Store.find(id) ?: return
        if (r.status == "paused" || r.status == "failed") {
            r.status = "queued"; r.error = ""
            Store.saveDownloads(true); Store.fireDownloads()
            if (kick) DownloadService.kick(app) else pump()
        }
    }

    fun cancel(id: String) {
        val r = Store.removeDownload(id) ?: return
        r.status = "canceled"
        jobs[id]?.cancel(); calls[id]?.cancel()
        cancelNotif(r)
        scope.launch { Storage.partFile(app, id).delete() }
        main.post { idleCallback?.invoke() }
    }

    fun delete(id: String) {
        val r = Store.find(id) ?: return
        if (r.status != "completed") { cancel(id); return }
        scope.launch {
            Storage.deleteFile(app, r.uri)
            if (r.thumb.isNotEmpty() && !r.thumb.startsWith("http")) File(Storage.thumbDir(app), r.thumb).delete()
            Store.removeDownload(id)
        }
    }

    // ---------- Execução ----------
    private suspend fun runTask(rec: DownloadRecord) {
        try {
            var attempt = 0
            while (true) {
                try {
                    if (rec.hls) downloadHls(rec) else downloadHttp(rec)
                    break
                } catch (e: StoppedException) {
                    throw e
                } catch (e: IOException) {
                    if (rec.status != "downloading") throw StoppedException()
                    attempt++
                    if (attempt >= 4) throw e
                    rec.speed = 0; Store.fireDownloads()
                    delay(2000L * attempt)
                    if (rec.status != "downloading") throw StoppedException()
                }
            }
            complete(rec)
        } catch (ignored: StoppedException) {
        } catch (ignored: CancellationException) {
        } catch (e: Exception) {
            if (rec.status == "downloading") {
                rec.status = "failed"; rec.error = friendly(e); rec.speed = 0
                notifyFailed(rec)
            }
        } finally {
            jobs.remove(rec.id); calls.remove(rec.id)
            if (rec.status != "downloading" && rec.status != "completed") cancelProgressOnly(rec)
            Store.saveDownloads(true); Store.fireDownloads()
            pump()
            main.post { idleCallback?.invoke() }
        }
    }

    private fun checkActive(rec: DownloadRecord) { if (rec.status != "downloading") throw StoppedException() }

    private fun downloadHttp(rec: DownloadRecord) {
        val part = Storage.partFile(app, rec.id)
        var offset = if (part.exists()) part.length() else 0L
        if (offset > 0 && rec.total > 0 && offset > rec.total) { part.delete(); offset = 0 }
        val rb = Analyzer.req(rec.url, rec.referer)
        if (offset > 0) rb.header("Range", "bytes=$offset-")
        val call = dlClient.newCall(rb.build())
        calls[rec.id] = call
        call.execute().use { resp ->
            checkActive(rec)
            if (resp.code == 416) {
                if (rec.total > 0 && offset >= rec.total) { rec.downloaded = offset; return }
                part.delete(); rec.downloaded = 0
                throw IOException("A reiniciar a transferência")
            }
            if (!resp.isSuccessful) {
                if (resp.code >= 500) throw IOException("Servidor indisponível (HTTP ${resp.code})")
                throw HttpFailure(resp.code)
            }
            val ct = (resp.header("Content-Type") ?: "").lowercase()
            if (ct.startsWith("text/html") && !rec.mime.startsWith("text/")) {
                throw UserError("O servidor devolveu uma página em vez do ficheiro. O link pode ter expirado ou exigir sessão.")
            }
            val body = resp.body ?: throw IOException("Resposta vazia do servidor")
            val resumed = resp.code == 206 && offset > 0
            if (!resumed) offset = 0
            var total = -1L
            if (resp.code == 206) {
                total = resp.header("Content-Range")?.substringAfter('/', "")?.toLongOrNull() ?: -1L
                if (total < 0 && body.contentLength() >= 0) total = offset + body.contentLength()
            } else if (body.contentLength() >= 0) {
                total = body.contentLength()
            }
            rec.total = if (total > 0) total else 0L
            rec.sizeEstimated = false
            var downloaded = offset
            rec.downloaded = downloaded
            val buf = ByteArray(64 * 1024)
            var lastT = System.currentTimeMillis()
            var lastB = downloaded
            FileOutputStream(part, resumed).use { out ->
                val input = body.byteStream()
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    downloaded += n
                    rec.downloaded = downloaded
                    val now = System.currentTimeMillis()
                    if (now - lastT >= 500) {
                        val inst = (downloaded - lastB) * 1000 / (now - lastT)
                        rec.speed = if (rec.speed == 0L) inst else (rec.speed * 6 + inst * 4) / 10
                        rec.eta = if (rec.speed > 0 && rec.total > 0) (rec.total - downloaded) / rec.speed else -1
                        lastT = now; lastB = downloaded
                        tick(rec)
                    }
                    checkActive(rec)
                }
            }
            if (rec.total > 0 && downloaded < rec.total) throw IOException("Ligação interrompida")
            if (rec.total <= 0) rec.total = downloaded
        }
    }

    private fun fetchBytes(rec: DownloadRecord, url: String): ByteArray {
        val call = dlClient.newCall(Analyzer.req(url, rec.referer).build())
        calls[rec.id] = call
        call.execute().use { r ->
            if (!r.isSuccessful) {
                if (r.code >= 500) throw IOException("Servidor indisponível (HTTP ${r.code})")
                throw HttpFailure(r.code)
            }
            val body = r.body ?: throw IOException("Segmento vazio")
            if (body.contentLength() > 64L * 1024 * 1024) throw UserError("Segmento demasiado grande")
            return body.bytes()
        }
    }

    private fun downloadHls(rec: DownloadRecord) {
        val text = Analyzer.fetchText(rec.url, rec.referer) ?: throw IOException("Não foi possível obter a lista de reprodução")
        val pl = Analyzer.parseMediaPlaylist(rec.url, text)
        if (pl.encrypted) throw UserError("Este stream está protegido por encriptação e não pode ser descarregado.")
        if (pl.live) throw UserError("Transmissões em direto não são suportadas.")
        if (pl.segments.isEmpty()) throw UserError("Lista de reprodução vazia.")
        rec.segTotal = pl.segments.size
        rec.sizeEstimated = true
        val part = Storage.partFile(app, rec.id)
        if (rec.segIndex > 0 && part.exists() && rec.downloaded > 0) {
            RandomAccessFile(part, "rw").use { it.setLength(rec.downloaded) }
        } else {
            part.delete(); rec.segIndex = 0; rec.downloaded = 0
        }
        var written = rec.downloaded
        var lastT = System.currentTimeMillis()
        var window = 0L
        FileOutputStream(part, true).use { out ->
            if (rec.segIndex == 0 && pl.initUrl != null) {
                val d = fetchBytes(rec, pl.initUrl)
                out.write(d); written += d.size; rec.downloaded = written
            }
            for (i in rec.segIndex until pl.segments.size) {
                checkActive(rec)
                val data = fetchBytes(rec, pl.segments[i])
                out.write(data); out.flush()
                written += data.size; window += data.size
                rec.downloaded = written
                rec.segIndex = i + 1
                rec.total = (written.toDouble() / rec.segIndex * pl.segments.size).toLong()
                val now = System.currentTimeMillis()
                if (now - lastT >= 700) {
                    val inst = window * 1000 / (now - lastT)
                    rec.speed = if (rec.speed == 0L) inst else (rec.speed * 6 + inst * 4) / 10
                    val remaining = (rec.total - written).coerceAtLeast(0)
                    rec.eta = if (rec.speed > 0) remaining / rec.speed else -1
                    lastT = now; window = 0
                    tick(rec)
                }
            }
        }
    }

    private fun complete(rec: DownloadRecord) {
        val part = Storage.partFile(app, rec.id)
        if (!part.exists()) throw UserError("Ficheiro temporário em falta")
        val size = part.length()
        val (uri, loc) = Storage.publish(app, part, rec.fileName, rec.mime, rec.kind)
        rec.uri = uri; rec.location = loc; rec.total = size; rec.downloaded = size
        rec.sizeEstimated = false
        val t = Storage.makeThumb(app, uri, rec.kind, rec.id)
        if (t.isNotEmpty()) rec.thumb = t
        rec.completed = System.currentTimeMillis(); rec.speed = 0; rec.eta = 0
        rec.status = "completed"
        cancelNotif(rec)
        notifyDone(rec)
    }

    private fun tick(rec: DownloadRecord) {
        Store.saveDownloads(false)
        Store.fireDownloads()
        val now = System.currentTimeMillis()
        if (now - (lastNotif[rec.id] ?: 0L) >= 1000) {
            lastNotif[rec.id] = now
            notifyProgress(rec)
            updateSummary()
        }
    }

    private fun friendly(e: Throwable): String = when (e) {
        is UserError -> e.message ?: "Erro"
        is HttpFailure -> when (e.code) {
            401, 403 -> "Acesso negado pelo servidor (HTTP ${e.code}). O link pode ter expirado ou exigir autenticação."
            404, 410 -> "Ficheiro não encontrado (HTTP ${e.code}). O link pode ter expirado."
            else -> "O servidor respondeu com erro HTTP ${e.code}."
        }
        is UnknownHostException -> "Sem ligação à Internet ou servidor inacessível."
        is SocketTimeoutException -> "Tempo de ligação esgotado."
        is SSLException -> "Falha na ligação segura (HTTPS)."
        is IOException -> e.message?.takeIf { it.isNotBlank() }?.let { "Erro: $it" } ?: "Erro de rede."
        else -> e.message ?: "Erro desconhecido."
    }

    // ---------- Notificações ----------
    private fun nm() = NotificationManagerCompat.from(app)

    private fun openAppIntent(): PendingIntent {
        val i = Intent(app, MainActivity::class.java).putExtra("route", "downloads")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(app, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun actionIntent(action: String, id: String): PendingIntent {
        val i = Intent(app, DownloadService::class.java).setAction(action).putExtra(DownloadService.EXTRA_ID, id)
        val code = id.hashCode() xor action.hashCode()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(app, code, i, flags)
        else PendingIntent.getService(app, code, i, flags)
    }

    fun summaryNotification(): Notification {
        val n = jobs.size
        return NotificationCompat.Builder(app, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("VidMax")
            .setContentText(if (n > 0) "$n download(s) em curso" else "A preparar downloads…")
            .setOngoing(true).setOnlyAlertOnce(true).setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent()).build()
    }

    private fun updateSummary() {
        if (!serviceRunning) return
        try { nm().notify(NID_SERVICE, summaryNotification()) } catch (ignored: SecurityException) {}
    }

    private fun canNotify() = Store.notifications && try { nm().areNotificationsEnabled() } catch (ignored: Exception) { false }

    private fun notifyProgress(rec: DownloadRecord) {
        if (!canNotify()) return
        val text = buildString {
            append("${rec.pct()}%")
            if (rec.speed > 0) append(" · ${fmtBytes(rec.speed)}/s")
            if (rec.eta >= 0) append(" · ${rec.eta}s")
        }
        val b = NotificationCompat.Builder(app, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download).setContentTitle(rec.fileName).setContentText(text)
            .setOnlyAlertOnce(true).setOngoing(true).setContentIntent(openAppIntent())
            .setProgress(100, rec.pct(), !rec.hls && rec.total <= 0)
            .addAction(R.drawable.ic_stat_download, "Pausar", actionIntent(DownloadService.ACTION_PAUSE, rec.id))
            .addAction(R.drawable.ic_stat_download, "Cancelar", actionIntent(DownloadService.ACTION_CANCEL, rec.id))
        try { nm().notify(rec.id.hashCode(), b.build()) } catch (ignored: SecurityException) {}
    }

    private fun notifyDone(rec: DownloadRecord) {
        if (!canNotify()) return
        val b = NotificationCompat.Builder(app, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_download).setContentTitle("Download concluído")
            .setContentText(rec.fileName).setAutoCancel(true).setContentIntent(openAppIntent())
        try { nm().notify(rec.id.hashCode(), b.build()) } catch (ignored: SecurityException) {}
    }

    private fun notifyFailed(rec: DownloadRecord) {
        if (!canNotify()) return
        val b = NotificationCompat.Builder(app, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_download).setContentTitle("Download falhou")
            .setContentText("${rec.fileName}: ${rec.error}").setAutoCancel(true).setContentIntent(openAppIntent())
            .setStyle(NotificationCompat.BigTextStyle().bigText("${rec.fileName}: ${rec.error}"))
        try { nm().notify(rec.id.hashCode(), b.build()) } catch (ignored: SecurityException) {}
    }

    private fun cancelNotif(rec: DownloadRecord) { lastNotif.remove(rec.id); try { nm().cancel(rec.id.hashCode()) } catch (ignored: Exception) {} }
    private fun cancelProgressOnly(rec: DownloadRecord) { if (rec.status != "failed") cancelNotif(rec) }

    private fun fmtBytes(n: Long): String {
        if (n < 1024) return "$n B"
        val u = arrayOf("KB", "MB", "GB")
        var v = n / 1024.0; var i = 0
        while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
        return String.format(java.util.Locale.US, "%.1f %s", v, u[i])
    }
}
