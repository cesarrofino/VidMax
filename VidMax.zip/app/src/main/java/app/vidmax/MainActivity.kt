package app.vidmax

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Ponte JavaScript <-> Kotlin. Exposta APENAS ao WebView da interface interna (nunca às páginas web). */
class UiBridge(private val act: MainActivity) {
    @JavascriptInterface
    fun invoke(cmd: String, arg: String): String = try {
        act.handle(cmd, arg)
    } catch (e: Exception) {
        JSONObject().put("ok", false).put("error", e.message ?: "erro").toString()
    }
}

class MainActivity : AppCompatActivity() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var browserHost: FrameLayout
    private lateinit var ui: UiWebView
    private lateinit var fullscreen: FrameLayout
    lateinit var browser: Browser
    private lateinit var loader: WebViewAssetLoader

    @Volatile private var uiReady = false
    private var keepSplash = true
    private var pendingShared: JSONObject? = null
    private var pendingRoute: String? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var permCb: ((Boolean) -> Unit)? = null
    private var dlThrottle = false

    // ---------- Launchers ----------
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        permCb?.invoke(res.values.all { it }); permCb = null
    }
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val uris: Array<Uri>? = if (r.resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) Array(clip.itemCount) { clip.getItemAt(it).uri }
            else data.data?.let { arrayOf(it) }
        } else null
        fileCb?.onReceiveValue(uris); fileCb = null
    }
    private val folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                Store.treeUri = uri.toString()
                Store.treeName = Storage.queryName(this, android.provider.DocumentsContract.buildDocumentUriUsingTree(
                    uri, android.provider.DocumentsContract.getTreeDocumentId(uri))) ?: "Pasta escolhida"
                emit("settings", settingsPayload().toString())
            } catch (e: Exception) { toast("Não foi possível usar essa pasta") }
        }
    }

    // ---------- Ciclo de vida ----------
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { keepSplash }
        handler.postDelayed({ keepSplash = false }, 3000)

        root = FrameLayout(this)
        browserHost = FrameLayout(this).apply { visibility = View.GONE }
        fullscreen = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.BLACK) }
        ui = UiWebView(this)
        root.addView(browserHost, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(ui, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(fullscreen, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)
        browser = Browser(this, browserHost)

        loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/thumbs/", WebViewAssetLoader.InternalStoragePathHandler(this, Storage.thumbDir(this)))
            .build()
        setupUi()
        applyTheme()
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) WebView.setWebContentsDebuggingEnabled(true)

        Store.dlListeners.add(dlListener)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { handleBack() }
        })

        browser.ensureTab()
        requestStartupPermissions()
        ui.loadUrl("${U.ASSET_ORIGIN}/assets/ui/index.html")
        handleIntent(intent)
        if (Downloads.queuedCount() > 0) DownloadService.kick(this) // recupera downloads interrompidos
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupUi() {
        ui.setBackgroundColor(Color.TRANSPARENT)
        ui.overScrollMode = View.OVER_SCROLL_NEVER
        ui.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportZoom(false)
            textZoom = 100
        }
        ui.addJavascriptInterface(UiBridge(this), "Android")
        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith(U.ASSET_ORIGIN)) return false
                if (u.startsWith("http")) { openInBrowser(u) }
                return true
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() { browser.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); browser.onResume() }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyTheme()
        emit("settings", settingsPayload().toString())
    }

    override fun onDestroy() {
        Store.dlListeners.remove(dlListener)
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        browser.destroy()
        ui.destroy()
        super.onDestroy()
    }

    // ---------- Tema ----------
    private fun applyTheme() {
        val dark = Store.effectiveDark(this)
        val bg = if (dark) 0xFF070B19.toInt() else 0xFFF5F8FF.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.setBackgroundDrawable(ColorDrawable(bg))
        root.setBackgroundColor(bg)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }

    private fun settingsPayload(): JSONObject = JSONObject()
        .put("settings", Store.settingsJson())
        .put("effective", if (Store.effectiveDark(this)) "dark" else "light")
        .put("version", versionName())

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
    } catch (ignored: Exception) { "1.0.0" }

    // ---------- Eventos para a interface ----------
    fun emit(name: String, json: String) {
        val safe = json.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
        ui.post { ui.evaluateJavascript("window.VM&&VM.emit(${JSONObject.quote(name)},$safe)", null) }
    }

    private val dlListener: () -> Unit = {
        if (!dlThrottle) {
            dlThrottle = true
            handler.postDelayed({
                dlThrottle = false
                emit("downloads", JSONObject().put("items", Store.listUi()).toString())
            }, 400)
        }
    }

    fun toast(msg: String) { runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }

    fun openExternal(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (ignored: Exception) { toast("Nenhuma aplicação disponível para abrir este link") }
    }

    fun copyText(t: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("VidMax", t))
        toast("Copiado")
    }

    fun shareText(t: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Partilhar"))
    }

    private fun openInBrowser(url: String) {
        browser.newTab(url, false)
        emit("route", JSONObject().put("route", "browser").toString())
    }

    fun analyzeUrl(url: String) {
        emit("shared", JSONObject().put("url", url).put("mode", "analyze").toString())
    }

    // ---------- Intents (Partilhar / abrir links) ----------
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        when (i.action) {
            Intent.ACTION_SEND -> {
                val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: i.getStringExtra(Intent.EXTRA_SUBJECT)
                val u = t?.let { Analyzer.extractUrl(it) }
                if (u != null) dispatchShared(u, "analyze") else toast("O conteúdo partilhado não contém um link.")
            }
            Intent.ACTION_VIEW -> {
                val u = i.dataString
                if (u != null && u.startsWith("http")) {
                    val analyze = Analyzer.platformOf(Analyzer.hostOf(u)) != null || U.isMediaUrl(u)
                    if (analyze) dispatchShared(u, "analyze") else { browser.newTab(u, false); dispatchShared(u, "browse") }
                }
            }
        }
        i.getStringExtra("route")?.let { r ->
            if (uiReady) emit("route", JSONObject().put("route", r).toString()) else pendingRoute = r
        }
        i.action = null
    }

    private fun dispatchShared(url: String, mode: String) {
        val o = JSONObject().put("url", url).put("mode", mode)
        if (uiReady) emit("shared", o.toString()) else pendingShared = o
    }

    private fun onUiReady() {
        uiReady = true
        keepSplash = false
        emit("downloads", JSONObject().put("items", Store.listUi()).toString())
        emit("browser", browser.stateJson().toString())
        pendingShared?.let { emit("shared", it.toString()) }; pendingShared = null
        pendingRoute?.let { emit("route", JSONObject().put("route", it).toString()) }; pendingRoute = null
    }

    // ---------- Permissões ----------
    private fun requestStartupPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 && !granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) ensurePerms(need.toTypedArray()) {}
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePerms(perms: Array<String>, cb: (Boolean) -> Unit) {
        val missing = perms.filter { !granted(it) }
        if (missing.isEmpty()) { cb(true); return }
        permCb = cb
        permLauncher.launch(missing.toTypedArray())
    }

    fun onWebPermission(r: PermissionRequest) {
        val res = r.resources
        val android = ArrayList<String>()
        val labels = ArrayList<String>()
        val grant = ArrayList<String>()
        for (x in res) {
            when (x) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> { android.add(Manifest.permission.CAMERA); labels.add("a câmara"); grant.add(x) }
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> { android.add(Manifest.permission.RECORD_AUDIO); labels.add("o microfone"); grant.add(x) }
                PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID -> grant.add(x) // reprodução protegida legítima
            }
        }
        if (grant.isEmpty()) { r.deny(); return }
        if (labels.isEmpty()) { r.grant(grant.toTypedArray()); return }
        AlertDialog.Builder(this)
            .setTitle("Permissão do site")
            .setMessage("${r.origin.host} quer usar ${labels.joinToString(" e ")}.")
            .setPositiveButton("Permitir") { _, _ ->
                ensurePerms(android.toTypedArray()) { ok -> if (ok) r.grant(grant.toTypedArray()) else r.deny() }
            }
            .setNegativeButton("Bloquear") { _, _ -> r.deny() }
            .setOnCancelListener { r.deny() }
            .show()
    }

    fun onWebGeo(origin: String, cb: GeolocationPermissions.Callback) {
        AlertDialog.Builder(this)
            .setTitle("Permissão do site")
            .setMessage("$origin quer saber a sua localização.")
            .setPositiveButton("Permitir") { _, _ ->
                ensurePerms(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)) { ok -> cb.invoke(origin, ok, false) }
            }
            .setNegativeButton("Bloquear") { _, _ -> cb.invoke(origin, false, false) }
            .setOnCancelListener { cb.invoke(origin, false, false) }
            .show()
    }

    fun onFileChooser(cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams): Boolean {
        fileCb?.onReceiveValue(null)
        fileCb = cb
        return try {
            val i = p.createIntent()
            if (p.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            fileLauncher.launch(i); true
        } catch (ignored: Exception) { fileCb = null; false }
    }

    // ---------- Ecrã inteiro (vídeo HTML5) ----------
    fun showCustomView(v: View, cb: WebChromeClient.CustomViewCallback) {
        if (customView != null) { cb.onCustomViewHidden(); return }
        customView = v; customCb = cb
        fullscreen.addView(v, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        fullscreen.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    fun hideCustomView() {
        val v = customView ?: return
        fullscreen.removeView(v)
        fullscreen.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden(); customCb = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    private fun handleBack() {
        if (customView != null) { hideCustomView(); return }
        ui.evaluateJavascript("(window.VM&&VM.back&&VM.back())") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    // ---------- Downloads vindos do navegador ----------
    fun onWebDownload(url: String, cd: String?, mime: String?, len: Long, referer: String) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("Este conteúdo é gerado pela própria página e não pode ser descarregado diretamente.")
            return
        }
        val name = URLUtil.guessFileName(url, cd, mime)
        var ext = U.extOf(name)
        val m0 = (mime ?: "").substringBefore(';').lowercase()
        if (ext.isEmpty()) ext = U.extFromMime(m0).ifEmpty { "bin" }
        val kind = U.kindOf(m0, ext)
        val o = JSONObject()
            .put("url", url).put("referer", referer).put("name", U.safeName(name.substringBeforeLast('.', name)) + "." + ext)
            .put("ext", ext).put("mime", U.normalizeMime(kind, ext, m0)).put("kind", kind).put("quality", "")
            .put("size", len).put("sizeEst", false).put("hls", false).put("segTotal", 0).put("ranges", true)
            .put("source", Analyzer.hostOf(url)).put("thumb", "").put("note", "")
        val res = JSONObject().put("ok", true).put("restricted", false).put("url", referer.ifEmpty { url })
            .put("platform", Analyzer.hostOf(url)).put("title", name).put("thumb", "").put("message", "")
            .put("options", JSONArray().put(o))
        emit("options", res.toString())
    }

    // ---------- Ponte: comandos ----------
    private fun js(vararg p: Pair<String, Any?>): String {
        val o = JSONObject()
        p.forEach { o.put(it.first, it.second) }
        return o.toString()
    }

    private fun onUi(block: () -> Unit) = runOnUiThread { try { block() } catch (e: Exception) { toast(e.message ?: "Erro") } }

    fun handle(cmd: String, arg: String): String {
        val a = try { JSONObject(if (arg.isBlank()) "{}" else arg) } catch (ignored: Exception) { JSONObject() }
        return when (cmd) {
            "ui.ready" -> { onUi { onUiReady() }; js("ok" to true) }
            "ui.route" -> { val r = a.optString("route"); onUi { browser.setVisible(r == "browser") }; "{}" }
            "ui.hole" -> { setHole(a); "{}" }
            "ui.toast" -> { toast(a.optString("msg")); "{}" }
            "ui.copy" -> { onUi { copyText(a.optString("text")) }; "{}" }
            "ui.external" -> { onUi { openExternal(a.optString("url")) }; "{}" }
            "ui.share" -> { onUi { shareText(a.optString("text")) }; "{}" }
            "ui.exit" -> { onUi { moveTaskToBack(true) }; "{}" }
            "ui.clipboard" -> {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                js("text" to t)
            }
            "app.shareApp" -> { onUi { shareText(getString(R.string.share_app_text)) }; "{}" }

            "settings.get" -> settingsPayload().toString()
            "settings.set" -> {
                Store.setSetting(a.optString("k"), a.opt("v"))
                onUi { applyTheme() }
                if (a.optString("k") == "maxConcurrent") Downloads.pump()
                settingsPayload().toString()
            }
            "settings.pickFolder" -> { onUi { folderLauncher.launch(null) }; "{}" }
            "settings.resetFolder" -> { Store.treeUri = ""; Store.treeName = ""; settingsPayload().toString() }
            "perm.notifications" -> { onUi { if (Build.VERSION.SDK_INT >= 33) ensurePerms(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) {} }; "{}" }

            "dl.analyze" -> {
                val url = a.optString("url"); val rid = a.optString("rid")
                scope.launch(Dispatchers.IO) {
                    val res = try { Analyzer.analyze(url) } catch (e: Exception) { Analyzer.err("Falha ao analisar o link.") }
                    emit("analyze", res.put("rid", rid).toString())
                }
                "{}"
            }
            "dl.start" -> {
                val arr = a.optJSONArray("options") ?: JSONArray()
                var n = 0
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val ext = o.optString("ext", "bin")
                    val kind = o.optString("kind", "file")
                    val rec = DownloadRecord(
                        UUID.randomUUID().toString(), o.getString("url"), o.optString("referer"),
                        o.optString("name", "download.$ext"), ext, U.normalizeMime(kind, ext, o.optString("mime")), kind,
                        o.optString("quality"), o.optString("source"), o.optBoolean("hls")
                    )
                    rec.total = o.optLong("size", 0L).coerceAtLeast(0L)
                    rec.sizeEstimated = o.optBoolean("sizeEst")
                    rec.segTotal = o.optInt("segTotal")
                    rec.thumb = o.optString("thumb")
                    Store.addDownload(rec); n++
                }
                onUi { Downloads.enqueued() }
                js("ok" to true, "n" to n)
            }
            "dl.list" -> js("items" to Store.listUi())
            "dl.pause" -> { Downloads.pause(a.optString("id")); "{}" }
            "dl.resume" -> { onUi { Downloads.resume(a.optString("id")) }; "{}" }
            "dl.cancel" -> { Downloads.cancel(a.optString("id")); "{}" }
            "dl.delete" -> { Downloads.delete(a.optString("id")); "{}" }
            "dl.open" -> { val id = a.optString("id"); onUi { fileAction(id) { Storage.openExternal(this, it) } }; "{}" }
            "dl.share" -> { val id = a.optString("id"); onUi { fileAction(id) { Storage.share(this, it) } }; "{}" }
            "dl.play" -> { val id = a.optString("id"); onUi { playRecord(id) }; "{}" }
            "dl.where" -> js("location" to (Store.find(a.optString("id"))?.location ?: ""))

            "hist.list" -> js("items" to Store.historyList())
            "hist.clear" -> { Store.clearHistory(); "{}" }
            "hist.remove" -> { Store.removeHistory(a.optString("url"), a.optLong("t")); "{}" }
            "bm.list" -> js("items" to Store.bookmarksList())
            "bm.toggle" -> {
                val added = Store.toggleBookmark(a.optString("url"), a.optString("title"))
                onUi { browser.notifyChanged() }
                js("added" to added)
            }
            "bm.remove" -> { Store.removeBookmark(a.optString("url")); onUi { browser.notifyChanged() }; "{}" }

            "br.state" -> browser.cachedState
            "br.go" -> { val t = a.optString("text"); onUi { browser.go(t) }; "{}" }
            "br.newTab" -> {
                val u = a.optString("url").ifEmpty { null }; val p = a.optBoolean("priv")
                onUi { browser.newTab(u?.let { browser.resolveInput(it) }, p) }; "{}"
            }
            "br.switch" -> { val id = a.optInt("id"); onUi { browser.switchTo(id) }; "{}" }
            "br.close" -> { val id = a.optInt("id"); onUi { browser.closeTab(id) }; "{}" }
            "br.closeAll" -> { onUi { browser.closeAll() }; "{}" }
            "br.back" -> { onUi { browser.back() }; "{}" }
            "br.forward" -> { onUi { browser.forward() }; "{}" }
            "br.reload" -> { onUi { browser.reload() }; "{}" }
            "br.home" -> { onUi { browser.home() }; "{}" }
            "br.scan" -> { val rid = a.optString("rid"); onUi { browser.scan(rid) }; "{}" }
            "br.current" -> js("url" to browser.currentUrl(), "title" to browser.currentTitle())

            "storage.info" -> storageInfo().toString()
            "cache.clear" -> {
                val freed = Storage.clearDir(cacheDir) + Storage.clearDir(externalCacheDir)
                onUi { browser.clearCache(); ui.clearCache(true) }
                js("freed" to freed)
            }
            "cookies.clear" -> { onUi { browser.clearSiteData() }; "{}" }
            else -> js("ok" to false, "error" to "comando desconhecido")
        }
    }

    private fun setHole(a: JSONObject) {
        val d = resources.displayMetrics.density
        val r = a.optJSONArray("r")
        val x = a.optJSONArray("ex")
        fun rect(j: JSONArray?): Rect? = if (j == null || j.length() < 4) null
            else Rect((j.getDouble(0) * d).toInt(), (j.getDouble(1) * d).toInt(), (j.getDouble(2) * d).toInt(), (j.getDouble(3) * d).toInt())
        ui.hole = rect(r)
        ui.exclude = rect(x)
    }

    private fun fileAction(id: String, block: (DownloadRecord) -> Boolean) {
        val rec = Store.find(id) ?: return
        if (!Storage.exists(this, rec.uri)) { toast("O ficheiro já não existe no dispositivo"); return }
        if (!block(rec)) toast("Nenhuma aplicação disponível para esta ação")
    }

    private fun playRecord(id: String) {
        val rec = Store.find(id) ?: return
        if (!Storage.exists(this, rec.uri)) { toast("O ficheiro já não existe no dispositivo"); return }
        if (rec.kind != "video" && rec.kind != "audio") { Storage.openExternal(this, rec); return }
        val list = Store.snapshot().filter { it.status == "completed" && it.kind == rec.kind && it.uri.isNotEmpty() }
            .sortedByDescending { it.completed }
        val idx = list.indexOfFirst { it.id == id }.coerceAtLeast(0)
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra("ids", list.map { it.id }.toTypedArray()).putExtra("index", idx))
    }

    private fun storageInfo(): JSONObject {
        var video = 0L; var audio = 0L; var other = 0L; var vc = 0; var ac = 0; var oc = 0; var partial = 0L
        for (r in Store.snapshot()) {
            if (r.status == "completed") when (r.kind) {
                "video" -> { video += r.total; vc++ }
                "audio" -> { audio += r.total; ac++ }
                else -> { other += r.total; oc++ }
            } else partial += r.downloaded
        }
        var free = 0L; var total = 0L
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            free = st.availableBytes; total = st.totalBytes
        } catch (ignored: Exception) {}
        val cache = Storage.dirSize(cacheDir) + Storage.dirSize(externalCacheDir)
        return JSONObject().put("video", video).put("audio", audio).put("other", other)
            .put("videoCount", vc).put("audioCount", ac).put("otherCount", oc).put("partial", partial)
            .put("free", free).put("total", total).put("cache", cache)
    }
}
