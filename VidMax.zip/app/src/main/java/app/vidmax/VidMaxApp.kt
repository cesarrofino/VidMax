package app.vidmax

import android.app.Application

class VidMaxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Downloads.init(this)
        Downloads.createChannels(this)
    }
}
