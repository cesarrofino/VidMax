package app.vidmax

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object Storage {
    fun partFile(ctx: Context, id: String): File {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val dir = File(base, "parts")
        dir.mkdirs()
        return File(dir, "$id.part")
    }

    fun thumbDir(ctx: Context): File = File(ctx.filesDir, "thumbs").also { it.mkdirs() }

    fun queryName(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (ignored: Exception) { null }

    /** Move o ficheiro temporário para o local final. Devolve (uri, localização legível). */
    fun publish(ctx: Context, part: File, name: String, mime: String, kind: String): Pair<String, String> {
        val tree = Store.treeUri
        if (tree.isNotEmpty()) {
            try { return publishTree(ctx, part, name, mime, Uri.parse(tree)) } catch (ignored: Exception) { /* usa a pasta padrão */ }
        }
        return if (Build.VERSION.SDK_INT >= 29) publishQ(ctx, part, name, mime, kind) else publishLegacy(ctx, part, name, mime, kind)
    }

    private fun publishTree(ctx: Context, part: File, name: String, mime: String, tree: Uri): Pair<String, String> {
        val r = ctx.contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(r, parent, mime, name)
            ?: throw IOException("Não foi possível criar o ficheiro na pasta escolhida")
        try {
            r.openOutputStream(doc)!!.use { out -> part.inputStream().use { it.copyTo(out, 256 * 1024) } }
        } catch (e: Exception) {
            try { DocumentsContract.deleteDocument(r, doc) } catch (ignored: Exception) {}
            throw e
        }
        part.delete()
        val folder = queryName(ctx, parent) ?: "Pasta escolhida"
        return doc.toString() to "$folder/${queryName(ctx, doc) ?: name}"
    }

    private fun publishQ(ctx: Context, part: File, name: String, mime: String, kind: String): Pair<String, String> {
        val collection: Uri
        val rel: String
        when (kind) {
            "video" -> { collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); rel = "Movies/VidMax" }
            "audio" -> { collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); rel = "Music/VidMax" }
            else -> { collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); rel = "Download/VidMax" }
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val r = ctx.contentResolver
        val uri = r.insert(collection, cv) ?: throw IOException("Não foi possível criar o ficheiro")
        try {
            r.openOutputStream(uri)!!.use { out -> part.inputStream().use { it.copyTo(out, 256 * 1024) } }
            r.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            try { r.delete(uri, null, null) } catch (ignored: Exception) {}
            throw e
        }
        part.delete()
        return uri.toString() to "$rel/${queryName(ctx, uri) ?: name}"
    }

    private fun publishLegacy(ctx: Context, part: File, name: String, mime: String, kind: String): Pair<String, String> {
        val base = when (kind) {
            "video" -> Environment.DIRECTORY_MOVIES
            "audio" -> Environment.DIRECTORY_MUSIC
            else -> Environment.DIRECTORY_DOWNLOADS
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(base), "VidMax")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Sem permissão para escrever no armazenamento")
        val stem = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var f = File(dir, name)
        var n = 1
        while (f.exists()) { f = File(dir, if (ext.isEmpty()) "$stem ($n)" else "$stem ($n).$ext"); n++ }
        part.inputStream().use { i -> FileOutputStream(f).use { o -> i.copyTo(o, 256 * 1024) } }
        part.delete()
        MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(mime), null)
        return Uri.fromFile(f).toString() to f.absolutePath
    }

    fun deleteFile(ctx: Context, uriStr: String): Boolean {
        if (uriStr.isEmpty()) return true
        val u = Uri.parse(uriStr)
        return try {
            when {
                u.scheme == "file" -> File(u.path ?: return false).delete()
                DocumentsContract.isDocumentUri(ctx, u) -> DocumentsContract.deleteDocument(ctx.contentResolver, u)
                else -> ctx.contentResolver.delete(u, null, null) > 0
            }
        } catch (ignored: Exception) { false }
    }

    fun exists(ctx: Context, uriStr: String): Boolean {
        if (uriStr.isEmpty()) return false
        val u = Uri.parse(uriStr)
        return try {
            if (u.scheme == "file") File(u.path ?: return false).exists()
            else { ctx.contentResolver.openFileDescriptor(u, "r")?.close(); true }
        } catch (ignored: Exception) { false }
    }

    /** Uri partilhável com outras aplicações. */
    fun shareUri(ctx: Context, uriStr: String): Uri {
        val u = Uri.parse(uriStr)
        return if (u.scheme == "file") FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(u.path!!)) else u
    }

    fun openExternal(ctx: Context, rec: DownloadRecord): Boolean = try {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(shareUri(ctx, rec.uri), rec.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i); true
    } catch (ignored: Exception) { false }

    fun share(ctx: Context, rec: DownloadRecord): Boolean = try {
        val i = Intent(Intent.ACTION_SEND).setType(rec.mime).putExtra(Intent.EXTRA_STREAM, shareUri(ctx, rec.uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Partilhar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (ignored: Exception) { false }

    /** Gera miniatura (frame de vídeo ou capa de áudio). Devolve o nome do ficheiro ou "". */
    fun makeThumb(ctx: Context, uriStr: String, kind: String, id: String): String {
        if (kind != "video" && kind != "audio") return ""
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(ctx, Uri.parse(uriStr))
            var bmp: Bitmap? = null
            if (kind == "audio") {
                mmr.embeddedPicture?.let { bmp = BitmapFactory.decodeByteArray(it, 0, it.size) }
            } else {
                bmp = mmr.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: mmr.getFrameAtTime(0)
            }
            val b = bmp ?: return ""
            val w = 360
            val h = (b.height * (w.toFloat() / b.width)).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(b, w, h, true)
            val f = File(thumbDir(ctx), "$id.jpg")
            FileOutputStream(f).use { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            "$id.jpg"
        } catch (ignored: Exception) { "" } finally { try { mmr.release() } catch (ignored: Exception) {} }
    }

    fun dirSize(f: File?): Long {
        if (f == null || !f.exists()) return 0
        if (f.isFile) return f.length()
        return f.listFiles()?.sumOf { dirSize(it) } ?: 0
    }

    fun clearDir(f: File?): Long {
        if (f == null || !f.exists()) return 0
        var freed = 0L
        f.listFiles()?.forEach { c ->
            freed += dirSize(c)
            if (c.isDirectory) c.deleteRecursively() else c.delete()
        }
        return freed
    }
}
